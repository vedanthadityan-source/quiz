// Exercises normal app operations with isolated HTTP cookie jars. Run against a
// local production server; it never rewrites existing quiz or user documents.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { randomBytes } from 'node:crypto'

const base = process.env.QUIZZO_TEST_URL || 'http://localhost:3100'
function client() {
  const jar = new Map()
  return async (body, query = '') => {
    const response = await fetch(`${base}/api/quizzo${query}`, {
      method: body ? 'POST' : 'GET',
      headers: {
        'Content-Type': 'application/json',
        Origin: base,
        Cookie: [...jar].map(([k, v]) => `${k}=${v}`).join('; '),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    })
    for (const cookie of response.headers.getSetCookie()) {
      const [pair] = cookie.split(';')
      const at = pair.indexOf('=')
      jar.set(pair.slice(0, at), pair.slice(at + 1))
    }
    return { status: response.status, data: await response.json() }
  }
}
const pause = ms => new Promise(resolve => setTimeout(resolve, ms))

test('production routes, concurrent spending, equipped looks, timed multiplayer, and one-time rewards', { timeout: 120000 }, async () => {
  const host = client(), account = client(), guest = client(), third = client()
  assert.equal((await fetch(base)).status, 200)
  assert.equal((await fetch(`${base}/quizzo-verification-missing`)).status, 404)
  const publicView = await host()
  assert.equal(publicView.status, 200)
  const quiz = publicView.data.docs.find(q => q.questions.length === 4)
  assert.ok(quiz)
  const email = `quizzo-check-${Date.now()}-${randomBytes(3).toString('hex')}@example.test`
  const password = randomBytes(18).toString('base64url')
  assert.equal((await account({ action: 'signup', email, password, name: 'Vault QA', avatar: 2 })).status, 200)
  let wallet = (await account(null, '?shop=true')).data
  assert.equal(wallet.coins, 300)
  assert.equal(wallet.catalog.length, 6)
  assert.equal((await guest({ action: 'buy', skinId: wallet.catalog[0].id })).status, 401)
  assert.equal((await account({ action: 'equip', skinId: wallet.catalog[5].id, avatar: 2, accent: 'mint' })).status, 400)

  const bids = wallet.catalog.slice(0, 2)
  const purchases = await Promise.all(bids.map(s => account({ action: 'buy', skinId: s.id, price: 0 })))
  assert.equal(purchases.filter(p => p.status === 200).length, 1, 'only one conflicting spend may succeed')
  wallet = (await account(null, '?shop=true')).data
  assert.equal(wallet.owned.length, 1)
  const bought = wallet.catalog.find(s => wallet.owned.includes(s.id))
  assert.ok(bought)
  const spentBalance = 300 - bought.price
  assert.equal(wallet.coins, spentBalance)
  assert.notEqual((await account({ action: 'buy', skinId: bought.id })).status, 200)
  assert.equal((await account({ action: 'equip', skinId: bought.id, avatar: 2, accent: 'mint' })).status, 200)
  wallet = (await account(null, '?shop=true')).data
  assert.equal(wallet.equipped, bought.id)
  assert.equal(wallet.accent, 'mint')
  assert.notEqual((await account({ action: 'buy', skinId: wallet.catalog[5].id })).status, 200)

  const hosted = await host({ action: 'host', quizId: quiz.id })
  assert.equal(hosted.status, 200)
  const code = hosted.data.code
  assert.equal((await account({ action: 'join', code, name: 'Vault QA', avatar: 2 })).status, 200)
  assert.equal((await guest({ action: 'join', code, name: 'Second Runner', avatar: 3 })).status, 200)
  assert.equal((await third({ action: 'join', code, name: 'Third Runner', avatar: 4 })).status, 200)
  assert.equal((await guest({ action: 'next', code })).status, 403)
  for (let i = 0; i < quiz.questions.length; i++) {
    assert.equal((await host({ action: 'next', code })).status, 200)
    const state = (await account(null, `?code=${code}`)).data
    assert.equal(state.questionIndex, i)
    const wait = new Date(state.startsAt).getTime() - Date.now()
    if (wait > 0) await pause(wait + 40)
    const right = quiz.questions[i].correct
    const first = await account({ action: 'answer', code, index: i, option: right, durationMs: 0 })
    assert.equal(first.status, 200, JSON.stringify(first.data))
    assert.ok(first.data.durationMs > 0, 'server ignores client-provided times')
    assert.ok(first.data.points > 1000 && first.data.points <= 1500)
    assert.notEqual((await account({ action: 'answer', code, index: i, option: right })).status, 200)
    await pause(80)
    assert.equal((await guest({ action: 'answer', code, index: i, option: right })).status, 200)
    assert.equal((await third({ action: 'answer', code, index: i, option: (right + 1) % 4 })).status, 200)
  }
  assert.equal((await host({ action: 'next', code })).status, 200)
  const final = (await account(null, `?code=${code}`)).data
  assert.equal(final.phase, 'finished')
  assert.equal(final.players.length, 3)
  assert.equal(final.players[0].name, 'Vault QA')
  assert.equal(final.players[0].correct, 4)
  assert.equal(final.players[0].accuracy, 100)
  assert.equal(final.players[0].fastestWins, 4)
  assert.ok(final.players[0].averageMs > 0)
  assert.equal(final.players[0].skin.name, bought.name)
  assert.equal(final.players[0].accent, 'mint')
  assert.equal(final.rewardCoins, 265)
  const reward = await account({ action: 'claim', code })
  assert.equal(reward.status, 200, JSON.stringify(reward.data))
  assert.equal(reward.data.earned, 265)
  assert.notEqual((await account({ action: 'claim', code })).status, 200)
  wallet = (await account(null, '?shop=true')).data
  assert.equal(wallet.coins, spentBalance + 265)
  assert.equal((await account({ action: 'logout' })).status, 200)
  assert.equal((await account({ action: 'login', email, password })).status, 200)
  const restored = (await account(null, '?shop=true')).data
  assert.equal(restored.coins, wallet.coins)
  assert.equal(restored.equipped, bought.id)
  assert.equal(restored.accent, 'mint')
})
