import Quizzo from './quizzo'

export default function HomePage() {
  return <Quizzo />
}
