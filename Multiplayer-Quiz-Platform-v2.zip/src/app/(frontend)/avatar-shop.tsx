'use client'

import { useEffect, useState } from 'react'
import { Avatar, avatarNames, Icon } from './art'
import { accentColors, type SkinLook } from './deluxe-avatar'

export type ShopItem = SkinLook & { id: string; description?: string | null; rarity: string; price: number; active?: boolean | null }
export type Wallet = { catalog: ShopItem[]; coins: number; owned: string[]; equipped: string | null; accent: string; starter: boolean }
const rarityStyle: Record<string, string> = {
  Rare: 'border-[#d4e5ef] bg-[#eaf4fb] text-[#326782]',
  Epic: 'border-[#e2d5f4] bg-[#f0e9fb] text-[#7442a5]',
  Legendary: 'border-[#f1d7a4] bg-[#fff3d9] text-[#8b601c]',
}
const button = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#7842d9] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#6530bd] disabled:cursor-not-allowed disabled:bg-[#e8e3ef] disabled:text-[#6f657b]'
const neutral = 'min-h-11 rounded-xl border border-[#e4deed] bg-white px-4 py-2 text-sm font-semibold text-[#65596f] hover:bg-[#f4eefb]'

export default function AvatarShop({ wallet, signedIn, avatar, onAction, onAuth, onPlay }: {
  wallet: Wallet | null; signedIn: boolean; avatar: number;
  onAction: (body: Record<string, unknown>) => Promise<void>; onAuth: () => void; onPlay: () => void;
}) {
  const [tab, setTab] = useState('All avatars')
  const [rarity, setRarity] = useState('All rarities')
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [accent, setAccent] = useState(wallet?.accent || 'violet')
  const [base, setBase] = useState(avatar)
  const [confirming, setConfirming] = useState(false)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  useEffect(() => {
    if (!wallet) return
    setSelectedId(wallet.equipped)
    setAccent(wallet.accent)
  }, [wallet?.equipped, wallet?.accent])
  const catalog = wallet?.catalog || []
  const selected = catalog.find(s => s.id === selectedId) || null
  const owned = !selected || !!wallet?.owned.includes(selected.id)
  const equipped = selectedId === (wallet?.equipped || null) && base === avatar && accent === wallet?.accent
  const filtered = catalog.filter(s => (tab !== 'My collection' || wallet?.owned.includes(s.id)) && (rarity === 'All rarities' || rarity === s.rarity))
  const feature = catalog.find(s => s.variant === 'dragon') || catalog[catalog.length - 1]

  async function submit(kind: 'buy' | 'equip') {
    if (!signedIn) { onAuth(); return }
    setBusy(true); setError(''); setMessage('')
    try {
      await onAction({ action: kind, skinId: selected?.id || null, avatar: base, accent })
      setConfirming(false)
      setMessage(kind === 'buy' ? `${selected?.name} is yours forever. Equip it below!` : 'Game face saved. You’ll wear it in your next live game.')
    } catch (e) { setError(e instanceof Error ? e.message : 'Unable to update your collection. Please try again.') }
    finally { setBusy(false) }
  }
  function select(item: ShopItem | null) {
    setSelectedId(item?.id || null)
    setConfirming(false); setMessage(''); setError('')
    if (window.matchMedia('(max-width: 1279px)').matches) {
      document.getElementById('avatar-fitting-room')?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' })
    }
  }

  return <div className="space-y-7">
    <section className="relative isolate overflow-hidden rounded-3xl bg-[#28203f] p-7 text-white md:p-9">
      <div className="absolute -right-8 -top-32 -z-10 h-[440px] w-[440px] rounded-full border-[45px] border-[#49335f]" />
      <div className="relative z-10 max-w-[540px]">
        <p className="mb-4 flex items-center gap-2 text-xs font-bold tracking-[.2em] text-[#e2cfa6]"><Icon name="shop" className="h-4 w-4" />THE AVATAR VAULT</p>
        <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight md:text-[40px]">Big brain energy.<br />Legendary game face.</h1>
        <p className="mt-4 max-w-[380px] text-sm leading-6 text-[#e0d6ed]">Earn your coins. Find your character. Make every entrance a little more epic.</p>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <span className="flex min-h-12 items-center gap-3 rounded-xl border border-[#786340] bg-[#443749] px-4"><span className="text-[#ffdc87]"><Icon name="coin" /></span><span className="font-display text-xl font-extrabold">{signedIn ? (wallet?.coins || 0).toLocaleString() : '300'}<span className="ml-2 text-sm font-medium text-[#eee3f6]">{signedIn ? 'your coins' : 'starter coins with an account'}</span></span></span>
          {!signedIn && <button className="min-h-11 rounded-xl bg-[#ffe1a0] px-4 text-sm font-bold text-[#443020]" onClick={onAuth}>Claim your free account<Icon name="arrow" className="ml-2 inline h-4 w-4" /></button>}
        </div>
      </div>
      {feature && <div className="absolute bottom-0 right-0 hidden h-[270px] w-[360px] min-[1450px]:block">
        <div className="absolute bottom-6 right-6 rotate-12"><Avatar n={0} skin={{ name: 'Orbit Ranger', variant: 'cosmic' }} accent="ice" className="h-32 w-32" /></div>
        <div className="absolute right-32 top-0 -rotate-12"><Avatar n={0} skin={feature} accent="mint" className="h-[180px] w-[180px] drop-shadow-xl" /></div>
        <span className="absolute bottom-8 left-8 -rotate-6 rounded-lg border border-[#9b7a49] bg-[#4e3a46] px-3 py-2 text-xs font-bold tracking-widest text-[#ffe0a0]">100% MAIN CHARACTER</span>
      </div>}
    </section>

    <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_290px]">
      <section className="min-w-0">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-4">
          <div role="tablist" aria-label="Avatar collections" className="flex rounded-xl border border-[#e6e0ed] bg-white p-1">
            {['All avatars', 'My collection', 'Original crew'].map(t => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`min-h-11 rounded-lg px-3 text-sm font-bold ${tab === t ? 'bg-[#eee6fa] text-[#723ab8]' : 'text-[#716579] hover:bg-[#f7f3fb]'}`}>{t}{t === 'My collection' && <span className="ml-1.5 rounded-full bg-[#ece6f2] px-1.5 text-xs text-[#665674]">{wallet?.owned.length || 0}</span>}</button>)}
          </div>
          {tab !== 'Original crew' && <select aria-label="Filter avatar rarity" className={`${neutral} max-w-full`} value={rarity} onChange={e => setRarity(e.target.value)}>{['All rarities', 'Rare', 'Epic', 'Legendary'].map(r => <option key={r}>{r}</option>)}</select>}
        </div>
        {tab === 'Original crew' ? <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">{avatarNames.map((name, i) => <button key={name} aria-pressed={!selected && base === i} className={`rounded-2xl border bg-white p-5 text-center ${!selected && base === i ? 'border-purple-600 ring-2 ring-purple-100' : 'border-[#e7e1ed]'}`} onClick={() => { select(null); setBase(i) }}><Avatar n={i} className="mx-auto h-20 w-20" /><span className="mt-3 block font-display text-sm font-bold">{name}</span><span className="mt-1 block text-xs text-[#64795e]">Always free</span></button>)}</div> :
          <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-3">{filtered.map(item => {
            const isOwned = wallet?.owned.includes(item.id)
            return <article key={item.id} className={`overflow-hidden rounded-2xl border bg-white transition ${selected?.id === item.id ? 'border-[#9e78d0] shadow-md shadow-purple-950/5' : 'border-[#e7e1ed]'}`}>
              <button aria-label={`Preview ${item.name}`} aria-pressed={selected?.id === item.id} onClick={() => select(item)} className="relative flex h-[186px] w-full items-center justify-center overflow-hidden bg-[#f0ebf7]">
                <div className="absolute h-36 w-36 rounded-full border-[18px] border-[#e6dcf0]" />
                <Avatar n={0} skin={item} accent={selected?.id === item.id ? accent : item.variant === 'phoenix' ? 'sunset' : item.variant === 'robot' ? 'ice' : item.variant === 'dragon' ? 'mint' : 'violet'} className="relative h-[145px] w-[145px] -rotate-3 drop-shadow-md transition hover:rotate-3" />
                {isOwned && <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-white px-2 py-1 text-xs font-bold text-[#47715b]"><Icon name="check" className="h-3 w-3" />Owned</span>}
              </button>
              <div className="p-4"><span className={`rounded-md border px-2 py-1 text-xs font-bold ${rarityStyle[item.rarity]}`}>{item.rarity}</span><h2 className="mt-3 font-display text-base font-extrabold">{item.name}</h2><p className="mt-2 min-h-12 text-sm leading-6 text-[#72667c]">{item.description}</p><div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#f0ebf5] pt-3"><span className="flex items-center gap-1.5 text-sm font-bold text-[#89631e]"><Icon name="coin" className="h-4 w-4" />{item.price.toLocaleString()}</span><button onClick={() => select(item)} className="min-h-11 rounded-lg bg-[#f0e8fb] px-3 text-sm font-bold text-[#7541b9] hover:bg-[#e6d8f7]">{wallet?.equipped === item.id ? 'Equipped' : isOwned ? 'Customize' : 'Try it on'}<Icon name="arrow" className="ml-1 inline h-4 w-4" /></button></div></div>
            </article>
          })}</div>}
        {tab !== 'Original crew' && !filtered.length && <div className="rounded-2xl border border-dashed border-purple-200 bg-white p-9 text-center"><Icon name="shop" className="mx-auto mb-3 h-8 w-8 text-purple-700" /><h2 className="font-display text-lg font-bold">Your legendary collection starts here.</h2><p className="mt-2 text-sm leading-6 text-slate-600">{!wallet ? 'Loading the vault…' : 'Browse the vault and unlock a character to make it yours.'}</p><button className={`${neutral} mt-4`} onClick={() => { setTab('All avatars'); setRarity('All rarities') }}>Explore all avatars</button></div>}
        <div className="mt-5 flex flex-wrap items-center gap-4 rounded-2xl border border-[#e8dfcd] bg-[#fff8ea] p-5"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-[#967330]"><Icon name="bolt" /></span><div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-[#624e2f]">Play smart. Dress legendary.</h3><p className="mt-1 text-sm leading-6 text-[#766747]">Live games earn 25 coins for playing, 25 per correct answer, plus speed and podium bonuses.</p></div><button onClick={onPlay} className="min-h-11 text-sm font-bold text-[#7c5424]">Find a game <span aria-hidden="true">↗</span></button></div>
      </section>

      <aside id="avatar-fitting-room" className="min-w-0 scroll-mt-5 rounded-2xl border border-[#e5dded] bg-white p-5 xl:sticky xl:top-6">
        <div className="flex items-center justify-between"><h2 className="font-display text-base font-extrabold">The fitting room</h2><span className="rounded-full bg-[#edf3ed] px-2 py-1 text-xs font-bold text-[#456b50]">Live preview</span></div>
        <div className="relative mt-5 flex h-52 items-center justify-center overflow-hidden rounded-2xl bg-[#f2edf8]"><div className="absolute h-40 w-40 rounded-full border-[16px] border-[#e6dcf1]" /><Avatar n={base} skin={selected} accent={accent} className="relative h-40 w-40 drop-shadow-lg" /></div>
        <h3 className="mt-5 font-display text-xl font-extrabold">{selected?.name || avatarNames[base]}</h3><p className="mt-1 text-sm text-[#76677e]">{selected ? `${selected.rarity} outfit · yours to customize` : 'Original crew · forever free'}</p>
        <p className="mb-3 mt-5 text-sm font-bold">Choose your aura</p>
        <div className="grid grid-cols-4 gap-2">{Object.keys(accentColors).map(a => <button key={a} aria-label={`${a} accent`} aria-pressed={accent === a} onClick={() => { setAccent(a); setConfirming(false) }} className={`flex min-h-11 items-center justify-center rounded-xl border-2 text-sm capitalize ${accent === a ? 'border-purple-600 bg-purple-50 font-bold text-purple-800' : 'border-[#e8e2ed] text-[#72677c]'}`}><span className={`h-5 w-5 rounded-full ${a === 'violet' ? 'bg-[#bd9be9]' : a === 'mint' ? 'bg-[#83cdb5]' : a === 'sunset' ? 'bg-[#efaf76]' : 'bg-[#99cce9]'}`} />{accent === a && <Icon name="check" className="ml-1 h-3 w-3" />}</button>)}</div><p className="mt-2 text-xs capitalize text-[#75657e]">{accent} edition{!selected ? ' · auras apply to shop outfits' : ''}</p>
        {message && <p role="status" className="mt-4 rounded-xl bg-[#edf5ef] p-3 text-sm leading-6 text-[#386247]">{message}</p>}
        {error && <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm leading-6 text-red-800">{error}</p>}
        {confirming && selected ? <div className="mt-5 rounded-xl border border-[#ead9b9] bg-[#fff8eb] p-4"><p className="text-sm font-bold text-[#70532f]">Unlock for {selected.price} coins?</p><p className="mt-2 text-sm leading-6 text-[#776749]">You’ll have {Math.max(0, (wallet?.coins || 0) - selected.price)} coins left. This outfit stays in your collection.</p><button disabled={busy} onClick={() => submit('buy')} className={`${button} mt-4 w-full`}>{busy ? 'Unlocking…' : 'Confirm unlock'}</button><button disabled={busy} onClick={() => setConfirming(false)} className="mt-1 min-h-11 w-full text-sm font-bold text-[#75614a]">Not just yet</button></div> :
          <button disabled={busy || (signedIn && ((!owned && (wallet?.coins || 0) < (selected?.price || 0)) || (owned && equipped)))} onClick={() => { if (!signedIn) onAuth(); else if (owned) submit('equip'); else setConfirming(true) }} className={`${button} mt-5 w-full`}>{!signedIn ? 'Sign in to unlock & equip' : busy ? 'Saving your look…' : owned ? equipped ? 'Currently equipped' : 'Equip this look' : (wallet?.coins || 0) < (selected?.price || 0) ? `Need ${(selected?.price || 0) - (wallet?.coins || 0)} more coins` : `Unlock for ${selected?.price} coins`}<Icon name={owned ? 'check' : 'coin'} className="h-4 w-4" /></button>}
        <p className="mt-3 text-center text-xs leading-5 text-[#776a81]">{signedIn ? 'Saved to your account. No real money required.' : 'Guests can try every look. An account saves unlocks.'}</p>
      </aside>
    </div>
  </div>
}
