import { useId } from 'react'

export type SkinLook = { name: string; variant: string }
export const accentColors: Record<string, { bright: string; soft: string; dark: string }> = {
  violet: { bright: '#be9bff', soft: '#e9dcff', dark: '#6b43ad' },
  mint: { bright: '#72edce', soft: '#d7fff1', dark: '#237665' },
  sunset: { bright: '#ffb16e', soft: '#ffe8cf', dark: '#b95331' },
  ice: { bright: '#86d6ff', soft: '#e2f7ff', dark: '#346898' },
}

export default function DeluxeAvatar({ skin, accent = 'violet', className = 'h-24 w-24' }: { skin: SkinLook; accent?: string; className?: string }) {
  const id = useId().replace(/:/g, '')
  const c = accentColors[accent] || accentColors.violet
  const v = skin.variant
  return <svg viewBox="0 0 180 180" className={`shrink-0 ${className}`} role="img" aria-label={`${skin.name}, ${accent} edition`}>
    <defs>
      <radialGradient id={`${id}-bg`}><stop stopColor={c.dark} /><stop offset="1" stopColor="#17152e" /></radialGradient>
      <linearGradient id={`${id}-body`} x2="1" y2="1"><stop stopColor={c.soft} /><stop offset="1" stopColor={c.bright} /></linearGradient>
      <linearGradient id={`${id}-gold`} x2="1" y2="1"><stop stopColor="#fff3af" /><stop offset=".5" stopColor="#ffd16c" /><stop offset="1" stopColor="#c78634" /></linearGradient>
    </defs>
    <rect x="4" y="4" width="172" height="172" rx="44" fill={`url(#${id}-bg)`} />
    <rect x="9" y="9" width="162" height="162" rx="39" fill="none" stroke={c.bright} strokeOpacity=".55" />
    {[25, 48, 137, 156].map((x, i) => <path key={x} d={`m${x} ${27 + i % 3 * 40} 2 5 5 2-5 2-2 5-2-5-5-2 5-2z`} fill={i % 2 ? '#ffe0a0' : c.bright} />)}
    <ellipse cx="90" cy="157" rx="52" ry="10" fill="#080b20" fillOpacity=".4" />
    {v === 'dragon' ? <>
      <path d="M53 119 15 72l6 45-6 23 43-3m67-18 40-47-6 45 6 23-43-3" fill={c.dark} stroke={c.bright} strokeWidth="3" />
      <path d="m28 105 24 19m100-19-24 19" stroke={c.bright} strokeWidth="2" />
      <path d="M52 105Q42 60 65 50L54 25l30 20h13l28-20-9 28q28 21 12 60l-7 42H60Z" fill={`url(#${id}-body)`} />
      <path d="m72 52 17-22 18 24" fill={c.dark} /><path d="m82 135 8-15 8 15-8 10z" fill="#fff4b8" />
      <path d="m60 83 22 4-12 9m50-13-22 4 12 9" fill="#28233e" /><ellipse cx="90" cy="110" rx="23" ry="14" fill={c.soft} /><path d="m84 110 6 5 6-5" fill="none" stroke={c.dark} strokeWidth="3" strokeLinecap="round" />
    </> : v === 'ninja' ? <>
      <path d="m119 58 33-23-10 27 20 12-40 5" fill={c.bright} /><path d="M45 91q-3-53 45-54t46 53l-10 45 12 23H44l10-25Z" fill="#26233f" stroke={c.bright} strokeWidth="3" />
      <path d="M46 67q43 12 88 0l-2 18q-46 11-85 0z" fill={c.bright} /><path d="m49 87 81 0-9 29-27 7-33-8z" fill={c.soft} /><path d="m62 98 17 4m40-4-17 4" stroke="#29233d" strokeWidth="5" strokeLinecap="round" />
      <path d="m57 126 66 29m-4-29-58 29" stroke={c.dark} strokeWidth="9" /><path d="m84 129 12 0 4 15-10 8-11-8z" fill="#ffe29d" />
    </> : v === 'robot' ? <>
      <path d="M90 35V22m-8 0h16" stroke={c.bright} strokeWidth="5" strokeLinecap="round" /><rect x="39" y="46" width="103" height="88" rx="24" fill={`url(#${id}-body)`} /><path d="M51 137h79l12 22H39z" fill={c.dark} stroke={c.bright} strokeWidth="3" />
      <rect x="30" y="72" width="13" height="35" rx="6" fill={c.dark} /><rect x="139" y="72" width="13" height="35" rx="6" fill={c.dark} /><rect x="51" y="65" width="78" height="43" rx="17" fill="#24223e" />
      <path d="M66 83h11m28 0h11" stroke={c.bright} strokeWidth="6" strokeLinecap="round" /><path d="M79 119h24" stroke={c.dark} strokeWidth="4" strokeLinecap="round" /><circle cx="90" cy="147" r="5" fill="#ffdc85" />
    </> : v === 'cosmic' ? <>
      <path d="M49 150q1-37 41-38 41 1 41 38" fill={c.dark} stroke={c.bright} strokeWidth="3" />
      <circle cx="91" cy="79" r="45" fill={`url(#${id}-body)`} /><circle cx="91" cy="79" r="33" fill="#21233e" /><path d="M65 72q24-24 52-6" fill="none" stroke={c.bright} strokeWidth="5" strokeLinecap="round" />
      <ellipse cx="78" cy="85" rx="4" ry="6" fill="#fff4dc" /><ellipse cx="104" cy="85" rx="4" ry="6" fill="#fff4dc" /><path d="m85 97 6 3 6-3" fill="none" stroke={c.bright} strokeWidth="3" strokeLinecap="round" />
      <ellipse cx="91" cy="96" rx="75" ry="15" transform="rotate(-27 91 96)" fill="none" stroke="#f6cf82" strokeWidth="5" /><rect x="74" y="129" width="34" height="24" rx="7" fill={c.soft} /><circle cx="85" cy="140" r="3" fill={c.dark} /><circle cx="98" cy="140" r="3" fill="#df8e66" />
    </> : v === 'phoenix' ? <>
      <path d="M55 135Q15 129 23 62l43 43m58 30q40-6 32-73l-43 43" fill={c.dark} stroke={c.bright} strokeWidth="3" />
      <path d="m36 103 21 18m88-18-21 18" stroke="#ffd188" strokeWidth="3" /><path d="M65 143Q37 85 72 59l5-30 17 22 23-22-2 37q34 27 0 77l-25 18Z" fill={`url(#${id}-body)`} />
      <path d="m61 83 23 5-11 10m48-15-23 5 11 10" fill="#2e2943" /><path d="m83 107 15 0-8 15z" fill="#da8e39" /><path d="m72 137 18-11 18 11-18 22z" fill="#ffe4a2" />
    </> : <>
      <path d="m51 153 4-48h71l4 48-40 13Z" fill={c.dark} stroke={c.bright} strokeWidth="3" /><path d="m59 110 31 29 31-29" fill={c.bright} />
      <path d="M52 81q-2-33 38-33t38 33v25q-5 28-38 28t-38-28Z" fill={c.soft} /><path d="m52 59-8-32 28 16 18-23 19 23 28-16-9 32z" fill={`url(#${id}-gold)`} stroke="#bd8b44" strokeWidth="2" />
      <path d="m83 45 7-10 7 10-7 9z" fill={c.dark} /><ellipse cx="74" cy="87" rx="4" ry="7" fill="#302638" /><ellipse cx="108" cy="87" rx="4" ry="7" fill="#302638" /><path d="M81 106q10 9 20-1" fill="none" stroke={c.dark} strokeWidth="3" strokeLinecap="round" /><path d="m86 140 8 0 4 12-8 6-8-6z" fill="#ffe1a1" />
    </>}
  </svg>
}
