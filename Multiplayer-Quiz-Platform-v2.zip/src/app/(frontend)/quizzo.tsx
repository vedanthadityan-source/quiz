'use client'

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Avatar, avatarNames, Icon, QuizArt } from './art'
import AvatarShop, { type Wallet } from './avatar-shop'
import LiveGame, { type RoomView } from './live-game'

type Question = { text: string; options: { text: string }[]; correct: number }
type Quiz = { id?: string | number; title: string; description?: string; subject: string; art: string; authorName?: string; questions: Question[]; _status?: string }
type User = { id: string | number; name: string; avatar: number }
type Room = RoomView
const subjects = ['All topics', 'Science', 'Mathematics', 'Geography', 'History', 'English', 'Technology']
const arts = ['space', 'earth', 'science', 'math', 'history', 'tech']
const blankQuestion = (): Question => ({ text: '', options: Array.from({ length: 4 }, () => ({ text: '' })), correct: 0 })
const newQuiz = (): Quiz => ({ title: '', description: '', subject: 'Science', art: 'space', questions: [blankQuestion()] })
const primary = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#7842d9] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#6630c5] disabled:opacity-60'
const secondary = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-[#e5e3ec] bg-white px-4 py-2.5 text-sm font-semibold text-[#454052] transition hover:bg-[#f5f1fc]'
const field = 'mt-2 min-h-11 w-full rounded-xl border border-[#dedbe7] bg-white px-4 py-3 text-sm text-[#302b40] placeholder:text-slate-600'

async function api(body: Record<string, unknown>) {
  const response = await fetch('/api/quizzo', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || 'Something went wrong.')
  return data
}

function Modal({ title, close, children, wide = false }: { title: string; close: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement
    const root = ref.current
    const elements = () => Array.from(root?.querySelectorAll<HTMLElement>('button:not([disabled]), input, select, textarea, [tabindex="0"]') || [])
    elements()[0]?.focus()
    const listener = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close()
      if (event.key === 'Tab') {
        const items = elements()
        const first = items[0], last = items[items.length - 1]
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
      }
    }
    document.addEventListener('keydown', listener)
    const overflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', listener); document.body.style.overflow = overflow; previous?.focus() }
  }, [close])
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#201735]/50 p-4 backdrop-blur-sm" onMouseDown={e => { if (e.target === e.currentTarget) close() }}>
    <div ref={ref} role="dialog" aria-modal="true" aria-labelledby="dialog-title" className={`max-h-[90vh] w-full overflow-y-auto rounded-3xl bg-[#faf9fc] p-6 shadow-2xl md:p-8 ${wide ? 'max-w-3xl' : 'max-w-lg'}`}>
      <div className="mb-6 flex items-center justify-between gap-4"><h2 id="dialog-title" className="font-display text-2xl font-extrabold">{title}</h2><button onClick={close} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white hover:bg-purple-100" aria-label="Close dialog"><Icon name="close" /></button></div>
      {children}
    </div>
  </div>
}

function QuizCard({ quiz, open, saved, toggleSave }: { quiz: Quiz; open: () => void; saved: boolean; toggleSave: () => void }) {
  return <article className="group min-w-0 overflow-hidden rounded-2xl border border-[#e8e6ed] bg-white transition duration-200 hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-950/5">
    <button onClick={open} className="relative block h-[164px] w-full overflow-hidden text-left" aria-label={`Open ${quiz.title}`}><QuizArt kind={quiz.art} /><span className="absolute bottom-3 left-3 rounded-md bg-white px-2.5 py-1 text-xs font-bold text-[#433b55]">{quiz.questions?.length || 0} questions</span><span className="absolute right-3 top-3 rounded-md bg-white px-2 py-1 text-xs font-bold text-[#514369]">QUIZ</span></button>
    <div className="p-4"><p className="mb-2 text-xs font-bold tracking-wide text-[#7852a5]">{quiz.subject.toUpperCase()}</p><button onClick={open} className="min-h-11 text-left font-display text-base font-extrabold leading-6 group-hover:text-[#7842d9]">{quiz.title}</button><div className="mt-4 flex items-center justify-between border-t border-[#f0eef4] pt-3"><span className="flex min-w-0 items-center gap-2 text-xs text-[#625d70]"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#ede7fb] font-bold text-[#7647bb]">{(quiz.authorName || 'Q').slice(0, 1)}</span><span className="truncate">{quiz.authorName || 'Quizzo creator'}</span></span><button className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-lg hover:bg-purple-50 ${saved ? 'text-[#7842d9]' : 'text-[#716a7f]'}`} aria-label={saved ? 'Unsave quiz' : 'Save quiz'} aria-pressed={saved} onClick={toggleSave}><Icon name="saved" className={saved ? 'fill-purple-100' : ''} /></button></div></div>
  </article>
}

export default function Quizzo() {
  const [view, setView] = useState('Discover')
  const [topic, setTopic] = useState('All topics')
  const [search, setSearch] = useState('')
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [mine, setMine] = useState<Quiz[]>([])
  const [user, setUser] = useState<User | null>(null)
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [avatar, setAvatar] = useState(0)
  const [saved, setSaved] = useState<(string | number)[]>([])
  const [modal, setModal] = useState<string | null>(null)
  const [selected, setSelected] = useState<Quiz | null>(null)
  const [draft, setDraft] = useState<Quiz>(newQuiz)
  const [authMode, setAuthMode] = useState('signup')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [code, setCode] = useState('')
  const [hostPace, setHostPace] = useState<'host' | 'student'>('host')
  const [roomCode, setRoomCode] = useState('')
  const [room, setRoom] = useState<Room | null>(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [practice, setPractice] = useState(0)
  const [answer, setAnswer] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const resumeEditor = useRef(false)
  const close = useRef(() => { setModal(null); setError('') }).current

  useEffect(() => {
    if (user && resumeEditor.current) {
      resumeEditor.current = false
      setModal('editor')
    }
  }, [user])

  async function load() {
    try {
      const res = await fetch('/api/quizzo')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setQuizzes(data.docs); setUser(data.user); setWallet(data.wallet || null)
      if (data.user) {
        setName(data.user.name); setAvatar(data.user.avatar || 0)
        const own = await fetch('/api/quizzo?mine=true').then(r => r.json())
        setMine(own.docs || [])
      } else setMine([])
    } catch (e) { setNotice(e instanceof Error ? e.message : 'Unable to load quizzes.') }
    finally { setLoading(false) }
  }
  useEffect(() => {
    load()
    try { setSaved(JSON.parse(localStorage.getItem('quizzo-saved') || '[]')); setAvatar(Number(localStorage.getItem('quizzo-avatar') || 0)) } catch { /* Browser storage is optional. */ }
  }, [])
  useEffect(() => {
    if (!roomCode) return
    let live = true
    const poll = async () => {
      try {
        const res = await fetch(`/api/quizzo?code=${roomCode}`)
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        if (live) setRoom(data)
      } catch (e) { if (live) setError(e instanceof Error ? e.message : 'Connection lost.') }
    }
    poll()
    const interval = setInterval(poll, 1800)
    return () => { live = false; clearInterval(interval) }
  }, [roomCode])
  useEffect(() => {
    if (!notice) return
    const timeout = setTimeout(() => setNotice(''), 5000)
    return () => clearTimeout(timeout)
  }, [notice])

  function open(which: string) {
    if (which === 'auth' && modal === 'editor') resumeEditor.current = true
    setError('')
    setModal(which)
  }
  function toggleSave(quiz: Quiz) {
    if (!quiz.id) return
    const next = saved.includes(quiz.id) ? saved.filter(id => id !== quiz.id) : [...saved, quiz.id]
    setSaved(next)
    try { localStorage.setItem('quizzo-saved', JSON.stringify(next)) } catch { setNotice('Saved for this visit only. Browser storage is unavailable.') }
  }
  async function run(task: () => Promise<void>) {
    setError(''); setBusy(true)
    try { await task() } catch (e) { setError(e instanceof Error ? e.message : 'Please try again.') } finally { setBusy(false) }
  }
  function create() { setDraft(newQuiz()); open('editor') }
  async function shopAction(body: Record<string, unknown>) {
    const data = await api(body)
    setWallet(data.wallet)
    if (body.action === 'equip') setAvatar(Number(body.avatar))
  }
  function chooseAvatar(i: number) {
    run(async () => {
      if (user) await shopAction({ action: 'equip', avatar: i, skinId: null, accent: wallet?.accent || 'violet' })
      setAvatar(i)
      try { localStorage.setItem('quizzo-avatar', String(i)) } catch { /* Guest preference is optional. */ }
    })
  }
  function preview(quiz: Quiz) { setSelected(quiz); open('preview') }
  function startPractice() { setPractice(0); setScore(0); setAnswer(null); open('practice') }
  async function host(quiz: Quiz, pace: 'host' | 'student' = hostPace) {
    await run(async () => { const data = await api({ action: 'host', quizId: quiz.id, pace }); setRoom(null); setRoomCode(data.code); open('room') })
  }
  const source = view === 'My library' ? mine : view === 'Saved quizzes' ? quizzes.filter(q => q.id && saved.includes(q.id)) : quizzes
  const filtered = source.filter(q => (topic === 'All topics' || q.subject === topic) && `${q.title} ${q.subject}`.toLowerCase().includes(search.toLowerCase()))
  const q = selected?.questions?.[practice]
  const equippedLook = wallet?.catalog.find(s => s.id === wallet.equipped) || null

  return <div className="min-h-screen overflow-x-hidden bg-[#f8f9fc] font-sans text-[#302b40]">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[220px] flex-col overflow-y-auto border-r border-[#eae8f0] bg-white px-4 py-8 lg:flex">
      <button onClick={() => setView('Discover')} className="mb-10 flex items-center gap-2.5 px-4 text-left" aria-label="Quizzo home"><span className="flex h-9 w-9 rotate-[-8deg] items-center justify-center rounded-xl bg-[#7842d9] font-display text-2xl font-extrabold text-white">q<span className="text-[#e3d18c]">.</span></span><span className="font-display text-[28px] font-extrabold tracking-[-1.4px]">quizzo<span className="text-[#7842d9]">.</span></span></button>
      <button onClick={create} className={`${primary} mx-1 mb-8 shadow-[0_4px_0_#5f2cb5]`}><Icon name="plus" />Create a quiz</button>
      <p className="mb-3 px-4 text-xs font-bold tracking-[1.8px] text-[#797284]">WORKSPACE</p>
      <nav className="space-y-2">{[['Discover', 'discover'], ['My library', 'library'], ['Saved quizzes', 'saved']].map(([label, icon]) => <button key={label} onClick={() => { setView(label); setTopic('All topics'); setSearch('') }} aria-current={view === label ? 'page' : undefined} className={`flex min-h-12 w-full items-center gap-3 rounded-xl px-4 text-sm font-semibold ${view === label ? 'bg-[#f0e9fc] text-[#7740cc]' : 'text-[#6b6476] hover:bg-[#f7f5fa]'}`}><Icon name={icon} />{label}{label === 'Saved quizzes' && saved.length > 0 && <span className="ml-auto text-xs">{saved.length}</span>}</button>)}</nav>
      <button onClick={() => setView('Avatar shop')} aria-current={view === 'Avatar shop' ? 'page' : undefined} className={`mt-2 flex min-h-12 w-full items-center gap-2 whitespace-nowrap rounded-xl px-3 text-sm font-semibold ${view === 'Avatar shop' ? 'bg-[#f0e9fc] text-[#7740cc]' : 'text-[#6b6476] hover:bg-[#f7f5fa]'}`}><Icon name="shop" />Avatar shop<span className="ml-auto rounded-md bg-[#fff0d5] px-1.5 py-1 text-xs font-bold text-[#875c1d]">NEW</span></button>
      <div className="mt-8 border-t border-[#efedf3] pt-6"><p className="mb-3 px-4 text-xs font-bold tracking-[1.8px] text-[#797284]">LET’S PLAY</p><button onClick={() => open('join')} className="flex min-h-12 w-full items-center gap-3 rounded-xl px-4 text-sm font-semibold text-[#6b6476] hover:bg-[#f7f5fa]"><Icon name="users" />Join a game<span className="ml-auto h-2 w-2 rounded-full bg-[#74b99a]" /></button><button onClick={() => { setView('Discover'); setTopic('All topics'); setNotice('Choose a quiz, then select Host live.') }} className="flex min-h-12 w-full items-center gap-3 rounded-xl px-4 text-sm font-semibold text-[#6b6476] hover:bg-[#f7f5fa]"><Icon name="bolt" />Host a game</button></div>
      <div className="mt-auto pt-6"><div className="relative rounded-2xl bg-[#f4f0fd] px-4 pb-4 pt-5 text-center"><div className="mx-auto mb-2 w-fit -rotate-6"><Avatar n={avatar} skin={equippedLook} accent={wallet?.accent} className="h-16 w-16" /></div><h3 className="font-display text-sm font-extrabold">A little more you.</h3><p className="mt-1 text-sm leading-5 text-[#6a607a]">Big personality. Tiny avatar.</p><button onClick={() => setView('Avatar shop')} className="mt-2 min-h-11 text-sm font-bold text-[#7740cc]">Find your legendary look <span aria-hidden="true">↗</span></button></div><button onClick={() => open('help')} className="mt-4 flex min-h-11 items-center gap-3 px-4 text-sm text-[#6b6476]"><Icon name="help" />Help & how to play</button></div>
    </aside>

    <div className="lg:ml-[220px]">
      <header className="flex min-h-[86px] items-center justify-between gap-4 border-b border-[#eae8f0] bg-white px-5 md:px-9">
        <div className="flex items-center gap-3"><span className="font-display text-2xl font-extrabold text-[#7842d9] lg:hidden">quizzo.</span><span className="hidden text-sm font-semibold text-[#6b6476] md:block">{view}</span></div>
        <div className="flex items-center gap-3 md:gap-5">
          <button onClick={() => setView('Avatar shop')} aria-label="Open avatar shop and coin wallet" className="hidden min-h-11 items-center gap-2 rounded-xl bg-[#fff5e2] px-3 text-sm font-bold text-[#85601f] md:flex"><Icon name="coin" />{user ? wallet?.coins.toLocaleString() || '0' : 'Avatar shop'}</button>
          <button onClick={() => open('join')} className={`${secondary} hidden sm:inline-flex`}><Icon name="users" />Enter game code</button>
          <span className="hidden h-7 w-px bg-[#e8e5ee] md:block" />
          {user ? <><button onClick={() => open('avatars')} className="flex min-h-11 items-center gap-2 text-sm font-semibold"><Avatar n={avatar} skin={equippedLook} accent={wallet?.accent} className="h-9 w-9" /><span className="hidden md:inline">{user.name}</span></button><button aria-label="Log out" className="flex h-11 w-11 items-center justify-center" onClick={() => run(async () => { await api({ action: 'logout' }); await load(); setNotice('You’re now playing as a guest.') })}><Icon name="logout" /></button></> : <><button onClick={() => { setAuthMode('login'); open('auth') }} className="min-h-11 text-sm font-bold text-[#635b71]">Log in</button><button onClick={() => { setAuthMode('signup'); open('auth') }} className={primary}>Sign up free<Icon name="arrow" className="hidden md:block" /></button></>}
        </div>
      </header>
      <nav className="flex gap-2 overflow-x-auto border-b border-[#eae8f0] bg-white px-5 py-2 lg:hidden">{['Discover', 'My library', 'Saved quizzes', 'Avatar shop'].map(v => <button key={v} className={`min-h-11 whitespace-nowrap rounded-lg px-3 text-sm font-semibold ${view === v ? 'bg-purple-100 text-purple-800' : 'text-slate-600'}`} onClick={() => { setView(v); setTopic('All topics') }}>{v}</button>)}</nav>
      <main className="mx-auto max-w-[1500px] p-5 md:px-9 md:py-8">
        {view === 'Avatar shop' ? <AvatarShop wallet={wallet} signedIn={!!user} avatar={avatar} onAction={shopAction} onAuth={() => { setAuthMode('signup'); open('auth') }} onPlay={() => { setView('Discover'); setNotice('Join a live game while signed in to earn coins. Ask a host for a code!') }} /> : <>
        {view === 'Discover' ? <>
          <section className="relative flex min-h-[260px] items-center overflow-hidden rounded-[22px] border border-[#e4dbf7] bg-[#eee7fa] px-6 py-8 md:px-9">
            <div className="relative z-10 max-w-[530px]"><div className="mb-3 flex items-center gap-2 text-xs font-extrabold tracking-[1.7px] text-[#745198]"><span className="h-1.5 w-1.5 rounded-full bg-[#8852c9]" />BIG CURIOSITY. ENDLESS POSSIBILITIES.</div><h1 className="font-display text-[34px] font-extrabold leading-[1.25] tracking-[-1.3px] md:text-[40px]">A little curiosity.<br />A whole lot of <span className="relative text-[#7842d9]">fun.<svg className="absolute -bottom-2 left-0 h-3 w-full" viewBox="0 0 90 12" aria-hidden="true"><path d="M2 7Q46-2 87 5M12 11Q50 4 80 9" fill="none" stroke="#bda2e7" strokeWidth="3" strokeLinecap="round" /></svg></span></h1><p className="mt-5 text-sm leading-6 text-[#6a5b7c] md:text-base">Discover a quiz. Challenge your friends. Make it your own.</p><button onClick={create} className={`${primary} mt-5 shadow-[0_3px_0_#5f2cb5]`}>Let’s make a quiz<Icon name="arrow" /></button></div>
            <div className="absolute -right-6 bottom-0 hidden h-[260px] w-[390px] xl:block"><div className="absolute bottom-[-105px] right-5 h-[320px] w-[320px] rounded-full border-[30px] border-[#e5d9f6]" /><div className="absolute right-[94px] top-[58px] rotate-[-9deg] drop-shadow-xl"><Avatar n={0} className="h-[172px] w-[172px]" /></div><div className="absolute right-4 top-10 rotate-12 rounded-2xl bg-[#fff6da] p-4 text-[#a67c29] shadow-sm"><Icon name="trophy" className="h-9 w-9" /></div><div className="absolute bottom-8 left-0 -rotate-12 rounded-2xl bg-white p-4 shadow-sm"><span className="font-display text-2xl font-extrabold text-[#8c62cb]">?</span></div><svg className="absolute left-10 top-6 h-16 w-16 text-[#a886d2]" viewBox="0 0 60 60" fill="none" aria-hidden="true"><path d="m30 4 6 18 19 7-19 6-6 20-7-20-19-6 19-7z" stroke="currentColor" strokeWidth="2" /></svg><span className="absolute bottom-7 right-9 rotate-12 rounded-lg bg-[#d6e9d8] px-3 py-2 text-sm font-bold text-[#3e7658]">+1,000 points</span></div>
          </section>
          <section className="mt-5 grid gap-4 md:grid-cols-3">{[
            ['Create a quiz', 'Your ideas. Your next great quiz.', 'plus', 'bg-[#eee7fc] text-[#8851cb]', create],
            ['Host a live game', 'Bring everyone into the fun.', 'bolt', 'bg-[#fff0da] text-[#ad792c]', () => { setNotice('Pick any quiz below to host a live game.'); document.getElementById('quiz-library')?.scrollIntoView({ behavior: 'smooth' }) }],
            ['Join a game', 'Got a code? You’re invited.', 'users', 'bg-[#e2f1eb] text-[#4b846b]', () => open('join')],
          ].map(([title, desc, icon, color, action]) => <button key={String(title)} onClick={action as () => void} className="flex min-w-0 items-center gap-3.5 rounded-2xl border border-[#e7e5ed] bg-white p-4 text-left transition hover:border-[#bca0e9] hover:shadow-sm"><span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${color}`}><Icon name={String(icon)} /></span><span className="min-w-0"><span className="block font-display text-sm font-extrabold">{String(title)}</span><span className="mt-1 block text-xs text-[#746c80]">{String(desc)}</span></span><Icon name="chevron" className="ml-auto h-4 w-4 text-[#80758e]" /></button>)}</section>
        </> : <section className="mb-6 flex flex-wrap items-center justify-between gap-4"><div><p className="mb-2 text-xs font-bold tracking-widest text-purple-700">YOUR QUIZ CORNER</p><h1 className="font-display text-3xl font-extrabold tracking-tight">{view}</h1><p className="mt-2 text-sm text-slate-600">{view === 'My library' ? 'Big ideas start here. Keep creating, editing, and sharing.' : 'Good quizzes are worth keeping. Bookmarks are saved in this browser.'}</p></div><button className={primary} onClick={create}><Icon name="plus" />Create a quiz</button></section>}

        <section id="quiz-library" className="mt-9">
          <div className="flex flex-wrap items-center justify-between gap-4"><div><div className="flex items-center gap-2"><h2 className="font-display text-[23px] font-extrabold tracking-[-.7px]">{view === 'Discover' ? 'Find your next “aha!”' : view === 'My library' ? 'Made by you' : 'Your favorites'}</h2>{view === 'Discover' && <span className="rounded-full bg-[#fff0d9] px-2.5 py-1 text-xs font-bold text-[#916020]">Handpicked for you</span>}</div><p className="mt-1.5 text-sm text-[#766d82]">{view === 'Discover' ? 'A world of quizzes. A topic for every kind of curious.' : `${source.length} quizzes in your collection`}</p></div><label className="flex min-h-11 w-full items-center gap-2 rounded-xl border border-[#e2dfe9] bg-white px-3 text-[#81768e] sm:w-[265px]"><Icon name="search" className="h-4 w-4" /><input aria-label="Search quizzes" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search quizzes, topics..." className="min-h-11 min-w-0 flex-1 bg-transparent text-sm text-[#51465f] outline-none" /><span className="rounded border border-[#e8e4ee] px-1.5 text-xs">⌕</span></label></div>
          <div role="tablist" aria-label="Quiz topics" className="my-5 flex flex-wrap gap-2">{subjects.map((s, i) => <button key={s} role="tab" aria-selected={topic === s} onClick={() => setTopic(s)} className={`flex min-h-11 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition ${topic === s ? 'border-[#7842d9] bg-[#7842d9] text-white' : 'border-[#e6e2ed] bg-white text-[#6f657c] hover:border-[#bba1dd]'}`}><span aria-hidden="true" className={topic === s ? 'text-white' : 'text-[#9d7cb6]'}>{['✧', '⚗', '＋', '◎', '▥', 'Aa', '⌘'][i]}</span>{s}</button>)}</div>
          {loading ? <div className="rounded-2xl border border-dashed border-purple-200 p-12 text-center text-sm text-slate-600">Finding your next great quiz…</div> : filtered.length ? <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">{filtered.map(quiz => <QuizCard key={quiz.id} quiz={quiz} open={() => preview(quiz)} saved={!!quiz.id && saved.includes(quiz.id)} toggleSave={() => toggleSave(quiz)} />)}</div> : <div className="rounded-2xl border border-dashed border-[#d8cde9] bg-white p-12 text-center"><div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-100 text-purple-700"><Icon name="library" /></div><h3 className="font-display text-xl font-bold">{view === 'My library' && !user ? 'Your next great quiz starts with you.' : 'A fresh page for your curiosity.'}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-slate-600">{view === 'My library' && !user ? 'Create a free account to save drafts, publish quizzes, and update them anytime.' : search || topic !== 'All topics' ? 'Try another topic or search to discover more quizzes.' : 'Create your first quiz, or discover a new favorite to save here.'}</p><button className={`${primary} mt-5`} onClick={view === 'My library' && !user ? () => open('auth') : create}>{view === 'My library' && !user ? 'Create your free account' : 'Create a quiz'}<Icon name="arrow" /></button></div>}
        </section>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#e4dcef] bg-[#f1edf8] px-6 py-5"><div className="flex items-center gap-4"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-[#9168c6]"><Icon name="globe" /></span><div><h3 className="font-display text-sm font-extrabold">Good quizzes bring people together.</h3><p className="mt-1 text-sm text-[#756980]">Make something curious. Share it with the world.</p></div></div><button onClick={create} className="flex min-h-11 items-center gap-2 text-sm font-bold text-[#7740cc]">Start creating<Icon name="arrow" /></button></div>
        <footer className="mt-7 flex flex-wrap justify-between gap-3 text-xs text-[#80768b]"><span>Made for curious minds. A little friendly competition encouraged.</span><span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[#7daf8e]" />You’re welcome here, guest or not.</span></footer>
        </>}
      </main>
    </div>
    {roomCode && modal !== 'room' && <button onClick={() => open('room')} className={`${primary} fixed bottom-5 right-5 z-40 shadow-lg`}><span className="h-2 w-2 rounded-full bg-green-200" />Return to game {roomCode}<Icon name="arrow" /></button>}
    {notice && <div role="status" className="fixed bottom-6 left-1/2 z-[70] flex max-w-[90vw] -translate-x-1/2 items-center gap-4 rounded-xl bg-[#352747] px-5 py-4 text-sm text-white shadow-xl">{notice}<button onClick={() => setNotice('')} className="flex h-11 w-11 shrink-0 items-center justify-center" aria-label="Dismiss message"><Icon name="close" /></button></div>}

    {modal === 'auth' && <Modal title={authMode === 'signup' ? 'Your curiosity belongs here.' : 'Welcome back, curious mind.'} close={close}><p className="mb-5 text-sm leading-6 text-slate-600">Save your creations, share your knowledge, and keep the fun going.</p><form onSubmit={e => { e.preventDefault(); run(async () => { const data = await api({ action: authMode, email, password, name, avatar }); setUser(data.user); setPassword(''); close(); await load(); setNotice('You’re in. Let’s make something great!') }) }} className="space-y-4">{authMode === 'signup' && <label className="block text-sm font-semibold">Your name<input className={field} value={name} onChange={e => setName(e.target.value)} required maxLength={40} autoComplete="name" placeholder="What should we call you?" /></label>}<label className="block text-sm font-semibold">Email address<input type="email" className={field} required value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" /></label><label className="block text-sm font-semibold">Password<input className={field} type="password" required minLength={8} maxLength={128} value={password} onChange={e => setPassword(e.target.value)} autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'} placeholder="At least 8 characters" /></label>{error && <p role="alert" className="text-sm text-red-700">{error}</p>}<button disabled={busy} className={`${primary} w-full`}>{busy ? 'One moment…' : authMode === 'signup' ? 'Create free account' : 'Log in'}<Icon name="arrow" /></button></form><div className="mt-5 text-center text-sm text-slate-600">{authMode === 'signup' ? 'Already part of the fun?' : 'New around here?'}<button className="ml-1 min-h-11 font-bold text-purple-700" onClick={() => { setAuthMode(authMode === 'signup' ? 'login' : 'signup'); setError('') }}>{authMode === 'signup' ? 'Log in' : 'Sign up free'}</button></div><button className="min-h-11 w-full text-sm font-semibold text-slate-600" onClick={() => { close(); setNotice('You’re playing as a guest. Join games or practice any public quiz!') }}>Keep exploring as a guest</button></Modal>}

    {modal === 'avatars' && <Modal title="Find your game face." close={close}>
      <p className="mb-5 text-sm text-slate-600">Your original crew. Always free, always you.</p>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">{avatarNames.map((a, i) => <button key={a} disabled={busy} aria-pressed={avatar === i && !equippedLook} onClick={() => chooseAvatar(i)} className={`rounded-2xl border-2 p-2 ${avatar === i && !equippedLook ? 'border-purple-600 bg-purple-100' : 'border-transparent bg-white hover:border-purple-200'}`}><Avatar n={i} className="mx-auto h-16 w-16" /><span className="mt-2 block text-sm font-semibold">{a}</span></button>)}</div>
      {error && <p role="alert" className="mt-4 text-sm text-red-800">{error}</p>}
      <button onClick={() => { close(); setView('Avatar shop') }} className={`${primary} mt-6 w-full`}><Icon name="shop" />Explore outfits & customize</button>
      <button onClick={close} className={`${secondary} mt-3 w-full`}>That’s my game face<Icon name="check" /></button>
    </Modal>}

    {modal === 'preview' && selected && <Modal title={selected.title} close={close}><div className="h-48 overflow-hidden rounded-2xl"><QuizArt kind={selected.art} /></div><div className="my-4 flex gap-3 text-xs font-semibold text-purple-700"><span>{selected.subject}</span><span>•</span><span>{selected.questions.length} questions</span><span>•</span><span>{selected._status === 'draft' ? 'Draft' : 'Public quiz'}</span></div><p className="mb-5 text-sm leading-6 text-slate-600">{selected.description || 'A fresh challenge for a curious mind. Ready to put your knowledge to the test?'}</p><div className="mb-5 rounded-2xl border border-[#e4dbf4] bg-white p-4"><p className="text-xs font-bold uppercase tracking-wider text-[#72518e]">Choose game pacing</p><div role="radiogroup" aria-label="Game pacing mode" className="mt-3 grid gap-2.5 sm:grid-cols-2"><button type="button" role="radio" aria-checked={hostPace === 'host'} onClick={() => setHostPace('host')} className={`rounded-xl border-2 p-3 text-left transition ${hostPace === 'host' ? 'border-[#7842d9] bg-[#f5efff]' : 'border-[#e8e3f0] bg-[#faf9fc] hover:border-purple-200'}`}><span className="flex items-center justify-between text-sm font-extrabold text-[#302b40]">Host-paced{hostPace === 'host' && <Icon name="check" className="h-4 w-4 text-[#7842d9]" />}</span><span className="mt-1 block text-xs leading-5 text-[#665b73]">Stop each question once everyone answers, reveal the answer, and view the leaderboard before moving on.</span></button><button type="button" role="radio" aria-checked={hostPace === 'student'} onClick={() => setHostPace('student')} className={`rounded-xl border-2 p-3 text-left transition ${hostPace === 'student' ? 'border-[#7842d9] bg-[#f5efff]' : 'border-[#e8e3f0] bg-[#faf9fc] hover:border-purple-200'}`}><span className="flex items-center justify-between text-sm font-extrabold text-[#302b40]">Student-paced{hostPace === 'student' && <Icon name="check" className="h-4 w-4 text-[#7842d9]" />}</span><span className="mt-1 block text-xs leading-5 text-[#665b73]">Players advance through questions on their own with an always-visible live leaderboard showing who is in front.</span></button></div></div><div className="grid gap-3 sm:grid-cols-2"><button className={primary} disabled={busy} onClick={() => host(selected, hostPace)}><Icon name="users" />Host {hostPace === 'student' ? 'student-paced' : 'host-paced'}</button><button className={secondary} onClick={startPractice}><Icon name="play" />Practice solo</button></div><div className="mt-3 flex gap-2">{mine.some(m => m.id === selected.id) && <button className={`${secondary} flex-1`} onClick={() => { setDraft(structuredClone(selected)); open('editor') }}><Icon name="edit" />Edit quiz</button>}<button className={`${secondary} flex-1`} onClick={() => toggleSave(selected)}><Icon name="saved" />{selected.id && saved.includes(selected.id) ? 'Saved in this browser' : 'Save for later'}</button></div>{error && <p className="mt-4 text-sm text-red-700" role="alert">{error}</p>}</Modal>}

    {modal === 'editor' && <Modal title={draft.id ? 'Make a good quiz even better.' : 'A new quiz. A new possibility.'} close={close} wide><div className="space-y-5"><label className="block text-sm font-bold">Give your quiz a name<input className={field} value={draft.title} maxLength={100} onChange={e => setDraft({ ...draft, title: e.target.value })} placeholder="The great space adventure" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-bold">Subject<select className={field} value={draft.subject} onChange={e => setDraft({ ...draft, subject: e.target.value })}>{[...subjects.slice(1), 'General knowledge'].map(s => <option key={s}>{s}</option>)}</select></label><label className="block text-sm font-bold">Cover illustration<select className={field} value={draft.art} onChange={e => setDraft({ ...draft, art: e.target.value })}>{arts.map(a => <option key={a} value={a}>{a.charAt(0).toUpperCase() + a.slice(1)}</option>)}</select></label></div><label className="block text-sm font-bold">A little introduction<textarea className={field} value={draft.description} maxLength={500} onChange={e => setDraft({ ...draft, description: e.target.value })} placeholder="What will players discover?" /></label>
      {draft.questions.map((question, qi) => <div key={qi} className="rounded-2xl border border-[#e5deee] bg-white p-5"><div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-bold text-purple-700">QUESTION {qi + 1}</h3>{draft.questions.length > 1 && <button className="min-h-11 px-2 text-sm font-semibold text-red-700" onClick={() => setDraft({ ...draft, questions: draft.questions.filter((_, i) => i !== qi) })}>Remove</button>}</div><input aria-label={`Question ${qi + 1}`} className={field} value={question.text} placeholder="Ask something interesting…" maxLength={300} onChange={e => setDraft({ ...draft, questions: draft.questions.map((v, i) => i === qi ? { ...v, text: e.target.value } : v) })} /><p className="mb-3 mt-4 text-xs text-slate-600">Add four answers. Select the circle next to the correct one.</p><div className="grid gap-3 sm:grid-cols-2">{question.options.map((option, oi) => <div className="flex items-center gap-2" key={oi}><button aria-label={`Mark option ${oi + 1} correct for question ${qi + 1}`} aria-pressed={question.correct === oi} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${question.correct === oi ? 'border-green-600 bg-green-100 text-green-800' : 'border-slate-200 text-slate-600'}`} onClick={() => setDraft({ ...draft, questions: draft.questions.map((v, i) => i === qi ? { ...v, correct: oi } : v) })}>{question.correct === oi ? <Icon name="check" /> : String.fromCharCode(65 + oi)}</button><input aria-label={`Answer ${oi + 1} for question ${qi + 1}`} className={`${field} mt-0 min-w-0`} maxLength={150} value={option.text} placeholder={`Answer ${oi + 1}`} onChange={e => setDraft({ ...draft, questions: draft.questions.map((v, i) => i === qi ? { ...v, options: v.options.map((o, j) => j === oi ? { text: e.target.value } : o) } : v) })} /></div>)}</div></div>)}
      <button disabled={draft.questions.length >= 50} className={`${secondary} w-full border-dashed`} onClick={() => setDraft({ ...draft, questions: [...draft.questions, blankQuestion()] })}><Icon name="plus" />Add a question</button>{!user && <p className="rounded-xl bg-purple-100 p-4 text-sm text-purple-900">Guests can create here. Sign in to save your quiz and publish it for everyone.</p>}{error && <p className="text-sm text-red-700" role="alert">{error}</p>}<div className="flex flex-wrap justify-end gap-3 border-t border-purple-100 pt-5"><button disabled={busy} className={secondary} onClick={() => { if (!user) { setAuthMode('signup'); open('auth'); return } run(async () => { const d = await api({ ...draft, action: 'save', published: false }); setDraft(d.doc); await load(); setNotice('Draft saved. Your ideas are safe.'); close(); setView('My library') }) }}>Save draft</button><button disabled={busy} className={primary} onClick={() => { if (!user) { setAuthMode('signup'); open('auth'); return } run(async () => { await api({ ...draft, action: 'save', published: true }); await load(); close(); setView('My library'); setNotice(draft.id ? 'Quiz updated and published for everyone!' : 'Your quiz is live. Let the fun begin!') }) }}><Icon name="globe" />{busy ? 'Saving…' : draft.id ? 'Publish updates' : 'Publish quiz'}</button></div></div></Modal>}

    {modal === 'join' && <Modal title="You’re invited to the fun." close={close}><p className="mb-5 text-sm text-slate-600">Get the 6-digit code from your host. No account needed.</p><form className="space-y-4" onSubmit={e => { e.preventDefault(); run(async () => { const data = await api({ action: 'join', code, name, avatar }); setRoom(null); setRoomCode(data.code); open('room') }) }}><label className="block text-sm font-bold">Game code<input className={`${field} text-center font-display text-3xl font-extrabold tracking-[.3em]`} placeholder="000000" inputMode="numeric" maxLength={6} required pattern="[0-9]{6}" value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></label><label className="block text-sm font-bold">Player name<input className={field} placeholder="Your legendary nickname" required maxLength={24} value={name} onChange={e => setName(e.target.value)} /></label><p className="text-sm font-bold">Pick your player</p><div className="grid grid-cols-6 gap-2">{avatarNames.map((a, i) => <button key={a} type="button" aria-label={a} aria-pressed={avatar === i} onClick={() => setAvatar(i)} className={`rounded-xl border-2 p-0.5 ${avatar === i ? 'border-purple-600' : 'border-transparent'}`}><Avatar n={i} className="h-auto w-full" /></button>)}</div>{error && <p role="alert" className="text-sm text-red-700">{error}</p>}<button className={`${primary} w-full`} disabled={busy}>{busy ? 'Joining…' : 'Let me in!'}<Icon name="arrow" /></button></form></Modal>}

    {modal === 'room' && <Modal title={room?.phase === 'finished' ? 'A podium worth celebrating.' : room?.host ? 'You’re the host. Bring the fun.' : 'Game face on. Let’s do this.'} close={close} wide>
      {room ? <LiveGame room={room} busy={busy} error={error} onClose={close}
        onCopy={() => { navigator.clipboard?.writeText(room.code).then(() => setNotice('Game code copied.')).catch(() => setNotice(`Your game code is ${room.code}`)) }}
        onShop={() => { close(); setView('Avatar shop') }}
        onAnswer={i => run(async () => {
          const res = await api({ action: 'answer', code: room.code, index: room.questionIndex, option: i })
          if (room.pace === 'student') {
            setNotice(res.correct ? `Correct! +${res.points.toLocaleString()} pts — on to the next question!` : `Not quite — on to the next question!`)
            const next = await fetch(`/api/quizzo?code=${room.code}`).then(r => r.json())
            setRoom(next)
          } else {
            setRoom({ ...room, answered: true, selectedOption: i })
          }
        })}
        onReveal={() => run(async () => { await api({ action: 'reveal', code: room.code }); const next = await fetch(`/api/quizzo?code=${room.code}`).then(r => r.json()); setRoom(next) })}
        onNext={() => run(async () => { await api({ action: 'next', code: room.code }); const next = await fetch(`/api/quizzo?code=${room.code}`).then(r => r.json()); setRoom(next) })}
        onClaim={() => run(async () => { const result = await api({ action: 'claim', code: room.code }); setWallet(result.wallet); setRoom({ ...room, rewardClaimed: true }); setNotice(`${result.earned} coins earned. Your next great look is waiting!`) })}
      /> : <p className="p-10 text-center text-sm text-slate-600">Opening your game room…{error}</p>}
    </Modal>}

    {modal === 'practice' && selected && <Modal title={practice >= selected.questions.length ? 'Curiosity looks good on you.' : `A little brain workout · ${practice + 1}/${selected.questions.length}`} close={close}>{practice >= selected.questions.length ? <div className="py-6 text-center"><Avatar n={avatar} className="mx-auto h-28 w-28" /><h3 className="mt-6 font-display text-4xl font-extrabold text-purple-700">{score} / {selected.questions.length}</h3><p className="mt-3 text-sm text-slate-600">Correct answers. Every question is a chance to learn.</p><button onClick={startPractice} className={`${primary} mt-6`}>Give it another go</button></div> : q && <><h3 className="mb-5 font-display text-xl font-bold leading-8">{q.text}</h3><div className="space-y-3">{q.options.map((o, i) => <button key={i} disabled={answer !== null} onClick={() => { setAnswer(i); if (i === q.correct) setScore(score + 1) }} className={`min-h-14 w-full rounded-xl border p-4 text-left text-sm font-semibold ${answer !== null && i === q.correct ? 'border-green-600 bg-green-100 text-green-900' : answer === i ? 'border-red-600 bg-red-100 text-red-900' : 'border-purple-200 bg-white hover:bg-purple-50'}`}><span className="mr-3">{String.fromCharCode(65 + i)}.</span>{o.text}</button>)}</div>{answer !== null && <><p className="mt-4 text-sm font-semibold text-purple-800">{answer === q.correct ? 'You nailed it. Nice work!' : `A new thing learned! The answer is ${q.options[q.correct]?.text}.`}</p><button className={`${primary} mt-5 w-full`} onClick={() => { setPractice(practice + 1); setAnswer(null) }}>{practice + 1 === selected.questions.length ? 'See my results' : 'Next question'}<Icon name="arrow" /></button></>}</>}</Modal>}
    {modal === 'help' && <Modal title="Less setup. More fun." close={close}>
      <div className="space-y-6">{[
        ['1. Find your curiosity', 'Explore the library by topic, or create your own quiz with four-choice questions.'],
        ['2. Get the crew together', 'Open a quiz and choose Host live. Share the six-digit code. Friends can join as guests, choose an avatar, and enter a nickname. The host controls the pace after each three-second countdown.'],
        ['3. Accuracy first. Speed second.', 'Every correct answer earns 1,000 points, plus up to 500 speed points during the first 30 seconds. Most correct answers wins; speed-adjusted points and average time break ties. The leaderboard shows accuracy, average time, personal fastest time, and fastest-correct badges. Older games without timing data show a dash.'],
        ['4. Earn your legendary look', 'Join live games while signed in, answer at least one question, and claim coins after the final podium. Earn 25 for playing, 25 per correct answer, 10 per fastest correct answer, plus podium bonuses of 100, 60, or 30 coins. Each game can be claimed once per account.'],
        ['5. Make it yours', 'Accounts start with 300 coins. Visit Avatar shop to unlock outfits, customize their aura, and equip them for your next game. Unlocks and equipment are saved to your account. Coins are earned in play, never bought with real money. Original avatars stay free for guests too.'],
        ['6. Keep creating', 'Save drafts, publish quizzes, and edit them anytime in My library. Bookmarks and guest avatar preferences stay in this browser.'],
      ].map(([title, description]) => <div key={title}><h3 className="font-display text-base font-bold text-purple-800">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{description}</p></div>)}</div>
      <button onClick={close} className={`${primary} mt-6 w-full`}>Got it. Let’s play!</button>
    </Modal>}
  </div>
}
