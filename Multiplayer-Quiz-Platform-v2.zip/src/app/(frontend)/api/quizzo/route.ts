import { getPayload } from 'payload'
import config from '@payload-config'
import { cookies } from 'next/headers'
import { randomBytes, timingSafeEqual, createHash } from 'node:crypto'
import { appAuth } from '@/lib/app-auth'
import { walletView } from '@/lib/avatar-wallet'
import { answerList, pointsFor, rewardFor, standings } from '@/lib/game-scoring'

export const dynamic = 'force-dynamic'
type Question = { text: string; options: { text: string }[]; correct: number }
const context = { gameServer: true }
const hash = (s: string) => createHash('sha256').update(s).digest('hex')
const equal = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b))
const clean = (v: unknown, max: number) => typeof v === 'string' ? v.trim().slice(0, max) : ''
const avatarValue = (v: unknown) => Number.isInteger(v) && Number(v) >= 0 && Number(v) <= 11 ? Number(v) : 0
const fail = (error: string, status = 400) => Response.json({ error }, { status })

export async function GET(request: Request) {
  try {
    const payload = await getPayload({ config })
    const authenticated = await appAuth.currentUser()
    const user = authenticated?.collection === 'users' ? authenticated : null
    const url = new URL(request.url)
    if (url.searchParams.get('shop') === 'true') return Response.json(await walletView(user))
    const code = url.searchParams.get('code')
    if (code) {
      const found = await payload.find({ collection: 'game-rooms', where: { code: { equals: code } }, limit: 1, depth: 0, overrideAccess: false, context, showHiddenFields: true })
      const room = found.docs[0]
      if (!room) return fail('That game code was not found.', 404)
      const jar = await cookies()
      const host = equal(hash(jar.get(`host-${code}`)?.value || ''), room.hostKey)
      const key = hash(jar.get(`player-${code}`)?.value || '')
      const players = await payload.find({ collection: 'game-players', where: { room: { equals: room.id } }, limit: 100, depth: 0, overrideAccess: false, context, showHiddenFields: true })
      const questions = room.questions as Question[]
      const pace = room.pace === 'student' ? 'student' : 'host'
      const me = players.docs.find(p => equal(key, p.key))
      const meAnswers = answerList(me?.answers)

      const roomIndex = room.questionIndex || 0
      const studentIndex = me ? Math.min(questions.length, Math.max(0, me.currentQuestionIndex ?? meAnswers.length)) : 0
      const effectiveIndex = pace === 'student' && !host ? studentIndex : roomIndex
      const q = questions[effectiveIndex]

      const completedCount = room.phase === 'finished'
        ? questions.length
        : pace === 'student'
          ? 0
          : (room.phase === 'playing' || room.phase === 'reveal') ? roomIndex + 1 : 0

      const ranked = standings(players.docs, questions, completedCount, { studentPaced: pace === 'student' })
      const skins = await payload.find({ collection: 'avatar-skins', overrideAccess: false, user, limit: 100, depth: 0 })
      const myRank = ranked.findIndex(p => p.id === me?.id)
      const eligible = !!user && !!me && me.account === user.id && room.phase === 'finished' && myRank >= 0
      const claimed = eligible ? await payload.find({ collection: 'wallet-events', overrideAccess: false, user, limit: 1, where: { operationKey: { equals: `reward:${user!.id}:${room.id}` } } }) : null

      const showQuestion = room.phase === 'playing' || (pace === 'host' && room.phase === 'reveal')
      const myAnswerForQ = meAnswers.find(a => a.index === effectiveIndex)
      let revealData: { correctIndex: number; optionCounts: number[]; answeredPlayers: number; totalPlayers: number } | null = null

      if (pace === 'host' && (room.phase === 'playing' || room.phase === 'reveal') && q) {
        const optionCounts = [0, 0, 0, 0]
        let answeredPlayers = 0
        for (const p of players.docs) {
          const ans = answerList(p.answers).find(a => a.index === roomIndex)
          if (ans) {
            answeredPlayers++
            if (ans.option >= 0 && ans.option <= 3) optionCounts[ans.option]++
          }
        }
        revealData = {
          correctIndex: room.phase === 'reveal' ? q.correct : -1,
          optionCounts: room.phase === 'reveal' ? optionCounts : [],
          answeredPlayers,
          totalPlayers: players.docs.length,
        }
      }

      const startsAt = pace === 'student' && !host
        ? (me?.currentQuestionStartedAt || room.questionStartedAt || null)
        : (room.questionStartedAt || null)

      const studentFinished = pace === 'student' && !host && room.phase === 'playing' && studentIndex >= questions.length

      return Response.json({
        code,
        title: room.title,
        pace,
        phase: room.phase,
        questionIndex: effectiveIndex,
        total: questions.length,
        host,
        startsAt,
        serverNow: Date.now(),
        rewardEligible: eligible,
        rewardClaimed: !!claimed?.docs.length,
        rewardCoins: eligible ? rewardFor(ranked[myRank], myRank) : 0,
        question: showQuestion && q && !studentFinished ? { text: q.text, options: q.options.map(o => o.text) } : null,
        answered: !!myAnswerForQ,
        selectedOption: myAnswerForQ ? myAnswerForQ.option : null,
        studentFinished,
        reveal: revealData,
        players: ranked.map(p => {
          const original = players.docs.find(v => v.id === p.id)!
          const skin = skins.docs.find(s => s.id === original.skin)
          const qAns = pace === 'host' ? answerList(original.answers).find(a => a.index === roomIndex) : undefined
          return {
            ...p,
            skin: skin ? { name: skin.name, variant: skin.variant } : null,
            accent: original.accent || 'violet',
            isMe: p.id === me?.id,
            answeredCurrent: !!qAns,
            correctCurrent: room.phase === 'reveal' && qAns && q ? qAns.option === q.correct : null,
            pointsCurrent: room.phase === 'reveal' && qAns && q ? pointsFor(qAns.option === q.correct, qAns.durationMs) : 0,
          }
        }),
      })
    }
    const mine = url.searchParams.get('mine') === 'true'
    if (mine && !user) return Response.json({ docs: [], user: null })
    const result = await payload.find({
      collection: 'quizzes', overrideAccess: false, user, depth: 0, limit: 100,
      ...(mine ? { draft: true, where: { owner: { equals: user!.id } } } : { where: { _status: { equals: 'published' as const } } }),
      sort: mine ? '-updatedAt' : 'createdAt',
    })
    return Response.json({ docs: result.docs, user: user ? { id: user.id, name: user.name, avatar: user.avatar || 0 } : null, wallet: await walletView(user) })
  } catch { return fail('Could not load data. Please try again.', 500) }
}

export async function POST(request: Request) {
  let action = ''
  try {
    const origin = request.headers.get('origin')
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host')
    if (origin && new URL(origin).host !== host) return fail('Invalid request origin.', 403)
    const b = await request.json()
    action = typeof b.action === 'string' ? b.action : ''
    const payload = await getPayload({ config })
    const authenticated = await appAuth.currentUser()
    const user = authenticated?.collection === 'users' ? authenticated : null
    if (b.action === 'logout') { await appAuth.logout(); return Response.json({ ok: true }) }
    if (b.action === 'buy') {
      if (!user) return fail('Sign in to unlock avatars and save your collection.', 401)
      await payload.create({ collection: 'wallet-events', overrideAccess: false, user, context: { walletServer: true }, data: { kind: 'purchase', skin: b.skinId, owner: user.id, amount: 0, balanceAfter: 0, sequence: 0, sequenceKey: 'pending', operationKey: 'pending' } })
      return Response.json({ wallet: await walletView(user) })
    }
    if (b.action === 'equip') {
      if (!user) return fail('Sign in to save your custom avatar.', 401)
      if (!['violet', 'mint', 'sunset', 'ice'].includes(b.accent)) return fail('Choose a valid accent color.')
      if (!Number.isInteger(b.avatar) || b.avatar < 0 || b.avatar > 11) return fail('Choose a valid base avatar.')
      await payload.update({ collection: 'users', id: user.id, overrideAccess: false, user, data: { avatar: b.avatar, equippedSkin: b.skinId || null, avatarAccent: b.accent } })
      return Response.json({ wallet: await walletView(user) })
    }
    if (b.action === 'login' || b.action === 'signup') {
      const email = clean(b.email, 200).toLowerCase()
      const password = typeof b.password === 'string' ? b.password : ''
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8 || password.length > 128) return fail('Enter a valid email and a password of 8–128 characters.')
      if (b.action === 'signup') {
        const name = clean(b.name, 40)
        if (!name) return fail('Please enter your name.')
        await payload.create({ collection: 'users', overrideAccess: false, data: { email, password, name, avatar: avatarValue(b.avatar) } })
      }
      const logged = await appAuth.login(email, password)
      return Response.json({ user: { id: logged.id, name: 'name' in logged ? logged.name : 'Player', avatar: 'avatar' in logged ? logged.avatar : 0 } })
    }
    if (b.action === 'save') {
      if (!user) return fail('Sign in to save and publish your quizzes.', 401)
      const title = clean(b.title, 100)
      const subjects = ['Science', 'Mathematics', 'Geography', 'History', 'English', 'Technology', 'General knowledge']
      if (!title || !subjects.includes(b.subject) || !Array.isArray(b.questions) || !b.questions.length || b.questions.length > 50) return fail('Add a title, subject, and 1–50 questions.')
      const questions: Question[] = b.questions.map((q: Question) => ({
        text: clean(q.text, 300), options: Array.isArray(q.options) ? q.options.map(o => ({ text: clean(o.text, 150) })) : [], correct: q.correct,
      }))
      if (questions.some(q => !q.text || q.options.length !== 4 || q.options.some(o => !o.text) || !Number.isInteger(q.correct) || q.correct < 0 || q.correct > 3)) return fail('Complete every question and all four answers. Select the correct answer.')
      const art = ['space', 'earth', 'science', 'math', 'history', 'tech'].includes(b.art) ? b.art : 'space'
      const data = { title, description: clean(b.description, 500), subject: b.subject, art, questions, authorName: 'name' in user ? String(user.name) : 'Creator', _status: b.published ? 'published' as const : 'draft' as const }
      const doc = b.id
        ? await payload.update({ collection: 'quizzes', id: b.id, data, user, overrideAccess: false, draft: !b.published })
        : await payload.create({ collection: 'quizzes', data, user, overrideAccess: false, draft: !b.published })
      return Response.json({ doc })
    }
    const jar = await cookies()
    const setKey = (name: string, value: string) => jar.set(name, value, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 86400 })
    if (b.action === 'host') {
      const quiz = await payload.findByID({ collection: 'quizzes', id: b.quizId, user, overrideAccess: false, depth: 0 })
      const code = String(100000 + randomBytes(4).readUInt32BE() % 900000)
      const secret = randomBytes(32).toString('hex')
      const pace = b.pace === 'student' ? 'student' : 'host'
      await payload.create({ collection: 'game-rooms', overrideAccess: false, context, data: { code, title: quiz.title, hostKey: hash(secret), questions: quiz.questions, pace, phase: 'lobby', questionIndex: 0 } })
      setKey(`host-${code}`, secret)
      return Response.json({ code })
    }
    const code = clean(b.code, 6)
    if (!/^\d{6}$/.test(code)) return fail('Enter the 6-digit game code.')
    const found = await payload.find({ collection: 'game-rooms', where: { code: { equals: code } }, limit: 1, overrideAccess: false, context, showHiddenFields: true, depth: 0 })
    const room = found.docs[0]
    if (!room) return fail('That room does not exist. Check your code.')
    const pace = room.pace === 'student' ? 'student' : 'host'

    if (b.action === 'claim') {
      if (!user) return fail('Join games while signed in to earn account coins.', 401)
      const key = hash(jar.get(`player-${code}`)?.value || '')
      const mine = await payload.find({ collection: 'game-players', overrideAccess: false, user, context, depth: 0, showHiddenFields: true, limit: 1, where: { and: [{ room: { equals: room.id } }, { account: { equals: user.id } }] } })
      if (!mine.docs.some(p => equal(p.key, key))) return fail('This game reward belongs to its signed-in player.', 403)
      const event = await payload.create({ collection: 'wallet-events', overrideAccess: false, user, context: { walletServer: true }, data: { kind: 'reward', room: room.id, owner: user.id, amount: 0, balanceAfter: 0, sequence: 0, sequenceKey: 'pending', operationKey: 'pending' } })
      return Response.json({ earned: event.amount, wallet: await walletView(user) })
    }
    if (b.action === 'join') {
      if (room.phase === 'finished') return fail('This game has already finished.')
      if (pace === 'host' && room.phase !== 'lobby') return fail('This game has already started.')
      const name = clean(b.name, 24)
      if (!name) return fail('Choose a player name.')
      if (user) {
        const joined = await payload.find({ collection: 'game-players', overrideAccess: false, user, context, limit: 1, depth: 0, showHiddenFields: true, where: { and: [{ room: { equals: room.id } }, { account: { equals: user.id } }] } })
        if (joined.docs.length) {
          if (equal(joined.docs[0].key, hash(jar.get(`player-${code}`)?.value || ''))) return Response.json({ code })
          return fail('This account has already joined. Continue in the original browser.')
        }
      }
      const secret = randomBytes(32).toString('hex')
      const skinId = user && (typeof user.equippedSkin === 'object' ? user.equippedSkin?.id : user.equippedSkin)
      const initialStart = pace === 'student' && room.phase === 'playing' ? new Date(Date.now() + 3000).toISOString() : undefined
      await payload.create({
        collection: 'game-players',
        overrideAccess: false,
        context,
        user,
        data: {
          room: room.id,
          name,
          avatar: avatarValue(b.avatar),
          key: hash(secret),
          score: 0,
          answers: [],
          currentQuestionIndex: 0,
          ...(initialStart ? { currentQuestionStartedAt: initialStart } : {}),
          account: user?.id || null,
          skin: skinId || null,
          accent: user?.avatarAccent || 'violet',
        },
      })
      setKey(`player-${code}`, secret)
      return Response.json({ code })
    }
    if (b.action === 'reveal') {
      if (!equal(hash(jar.get(`host-${code}`)?.value || ''), room.hostKey)) return fail('Only the host can control the game.', 403)
      if (pace !== 'host') return fail('Reveal is only available in host-paced games.')
      if (room.phase !== 'playing') return fail('No active question to stop.')
      await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { phase: 'reveal' } })
      return Response.json({ ok: true })
    }
    if (b.action === 'next') {
      if (!equal(hash(jar.get(`host-${code}`)?.value || ''), room.hostKey)) return fail('Only the host can control the game.', 403)
      if (room.phase === 'finished') return fail('This game has already finished.')
      const qs = room.questions as Question[]
      if (pace === 'student') {
        if (room.phase === 'lobby') {
          const startedAt = new Date(Date.now() + 3000).toISOString()
          await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { questionIndex: 0, phase: 'playing', questionStartedAt: startedAt } })
          const players = await payload.find({ collection: 'game-players', context, overrideAccess: false, depth: 0, where: { room: { equals: room.id } }, limit: 100 })
          await Promise.all(players.docs.map(p => payload.update({ collection: 'game-players', id: p.id, context, overrideAccess: false, data: { currentQuestionIndex: 0, currentQuestionStartedAt: startedAt } })))
          return Response.json({ ok: true })
        }
        await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { phase: 'finished' } })
        return Response.json({ ok: true })
      }
      if (room.phase === 'playing') {
        await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { phase: 'reveal' } })
        return Response.json({ ok: true })
      }
      const index = room.phase === 'lobby' ? 0 : (room.questionIndex || 0) + 1
      await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { questionIndex: index, phase: index >= qs.length ? 'finished' : 'playing', questionStartedAt: new Date(Date.now() + 3000).toISOString() } })
      return Response.json({ ok: true })
    }
    if (b.action === 'answer') {
      if (room.phase !== 'playing') return fail(room.phase === 'reveal' ? 'Time is up for this question!' : 'Wait for the host to start.')
      const key = hash(jar.get(`player-${code}`)?.value || '')
      const result = await payload.find({ collection: 'game-players', context, overrideAccess: false, depth: 0, showHiddenFields: true, where: { room: { equals: room.id } }, limit: 100 })
      const player = result.docs.find(p => equal(p.key, key))
      if (!player) return fail('Join this game first.', 403)
      const qs = room.questions as Question[]
      const answers = answerList(player.answers)

      if (pace === 'student') {
        const index = Math.min(qs.length, Math.max(0, player.currentQuestionIndex ?? answers.length))
        if (index >= qs.length) return fail('You have already completed all questions!')
        if (b.index !== index || !Number.isInteger(b.option) || b.option < 0 || b.option > 3) return fail('This question has changed.')
        if (answers.some(a => a.index === index)) return fail('Answer already submitted.')
        const startedRef = player.currentQuestionStartedAt || room.questionStartedAt
        const durationMs = startedRef ? Date.now() - new Date(startedRef).getTime() : undefined
        if (durationMs !== undefined && durationMs < 0) return fail('Get ready! The question starts after the countdown.')
        const correct = qs[index].correct === b.option
        const points = pointsFor(correct, durationMs)
        const nextIndex = index + 1
        const nextAnswers = [...answers, { index, option: b.option, ...(durationMs !== undefined ? { durationMs } : {}) }]
        await payload.update({
          collection: 'game-players',
          id: player.id,
          overrideAccess: false,
          context,
          user,
          data: {
            answers: nextAnswers,
            score: (player.score || 0) + points,
            currentQuestionIndex: nextIndex,
            ...(nextIndex < qs.length ? { currentQuestionStartedAt: new Date().toISOString() } : {}),
          },
        })
        const allFinished = result.docs.every(p => p.id === player.id ? nextIndex >= qs.length : answerList(p.answers).length >= qs.length)
        if (allFinished && result.docs.length > 0) {
          await payload.update({ collection: 'game-rooms', id: room.id, context, overrideAccess: false, data: { phase: 'finished' } })
        }
        return Response.json({ ok: true, correct, correctIndex: qs[index].correct, points, durationMs, nextIndex, finished: nextIndex >= qs.length })
      }

      const index = room.questionIndex || 0
      if (b.index !== index || !Number.isInteger(b.option) || b.option < 0 || b.option > 3) return fail('This question has changed.')
      if (answers.some(a => a.index === index)) return fail('Answer already submitted.')
      const correct = qs[index].correct === b.option
      const durationMs = room.questionStartedAt ? Date.now() - new Date(room.questionStartedAt).getTime() : undefined
      if (durationMs !== undefined && durationMs < 0) return fail('Get ready! The question starts after the countdown.')
      const points = pointsFor(correct, durationMs)
      await payload.update({ collection: 'game-players', id: player.id, overrideAccess: false, context, user, data: { answers: [...answers, { index, option: b.option, ...(durationMs !== undefined ? { durationMs } : {}) }], score: (player.score || 0) + points } })
      return Response.json({ ok: true, points, durationMs })
    }
    return fail('Unknown action.')
  } catch (error) {
    const message = error instanceof Error ? error.message : ''
    if (action === 'answer' || action === 'claim') {
      console.error('Quizzo game action failed', { action, message, details: error && typeof error === 'object' && 'data' in error ? error.data : undefined })
    }
    if (/coins|avatar|claimed|wallet|unlock|game before|signed in|already own/i.test(message)) return fail(message)
    if (action === 'buy' || action === 'claim') return fail('Your wallet changed or that unlock was already processed. Refresh and try again.', 409)
    if (/credentials|password|locked/i.test(message)) return fail('Could not sign in. Check your email and password.', 401)
    if (/unique|already|email/i.test(message)) return fail('That email may already be registered. Try logging in.')
    return fail('We couldn’t complete that action. Please check your details and try again.')
  }
}
