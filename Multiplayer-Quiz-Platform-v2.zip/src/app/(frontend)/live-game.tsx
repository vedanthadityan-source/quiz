'use client'

import { useEffect, useRef, useState } from 'react'
import { Avatar, Icon } from './art'
import type { SkinLook } from './deluxe-avatar'

export type RankedPlayer = {
  id: string | number
  name: string
  avatar: number
  score: number
  correct: number
  answeredCount: number
  currentProgress?: number
  isDone?: boolean
  accuracy: number
  averageMs: number | null
  fastestMs: number | null
  fastestWins: number
  skin?: SkinLook | null
  accent?: string
  isMe: boolean
  answeredCurrent?: boolean
  correctCurrent?: boolean | null
  pointsCurrent?: number
}

export type RoomView = {
  code: string
  title: string
  pace: 'host' | 'student'
  phase: string
  questionIndex: number
  total: number
  host: boolean
  answered: boolean
  selectedOption?: number | null
  studentFinished?: boolean
  reveal?: {
    correctIndex: number
    optionCounts: number[]
    answeredPlayers: number
    totalPlayers: number
  } | null
  question: { text: string; options: string[] } | null
  players: RankedPlayer[]
  startsAt: string | null
  serverNow: number
  rewardEligible: boolean
  rewardClaimed: boolean
  rewardCoins: number
}

const time = (ms: number | null) => ms === null ? '—' : `${(ms / 1000).toFixed(2)}s`
const button = 'flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#7842d9] px-5 py-3 text-sm font-bold text-white hover:bg-[#6833bc] disabled:opacity-60'

export default function LiveGame({ room, busy, error, onAnswer, onNext, onReveal, onClaim, onClose, onShop, onCopy }: {
  room: RoomView
  busy: boolean
  error: string
  onAnswer: (i: number) => void
  onNext: () => void
  onReveal: () => void
  onClaim: () => void
  onClose: () => void
  onShop: () => void
  onCopy: () => void
}) {
  const [sort, setSort] = useState('Overall')
  const [now, setNow] = useState(room.serverNow)
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | number | null>(null)
  const prevRanksRef = useRef<Map<string | number, number>>(new Map())
  const [rankDeltas, setRankDeltas] = useState<Map<string | number, number>>(new Map())

  useEffect(() => {
    const localStart = Date.now()
    setNow(room.serverNow)
    const timer = setInterval(() => setNow(room.serverNow + Date.now() - localStart), 100)
    return () => clearInterval(timer)
  }, [room.serverNow])

  useEffect(() => {
    const nextRanks = new Map<string | number, number>()
    const nextDeltas = new Map<string | number, number>()
    room.players.forEach((p, idx) => {
      nextRanks.set(p.id, idx)
      const prev = prevRanksRef.current.get(p.id)
      if (prev !== undefined && prev !== idx) {
        nextDeltas.set(p.id, prev - idx)
      }
    })
    if (prevRanksRef.current.size > 0 && nextDeltas.size > 0) {
      setRankDeltas(nextDeltas)
    }
    prevRanksRef.current = nextRanks
  }, [room.players])

  const elapsed = room.startsAt ? now - new Date(room.startsAt).getTime() : null
  const countdown = elapsed !== null && elapsed < 0 ? Math.ceil(-elapsed / 1000) : 0
  const isStudent = room.pace === 'student'
  const isReveal = !isStudent && room.phase === 'reveal'
  const finished = room.phase === 'finished'

  const ranked = [...room.players].sort((a, b) =>
    sort === 'Accuracy'
      ? b.accuracy - a.accuracy || b.correct - a.correct || b.score - a.score
      : sort === 'Fastest'
        ? (a.averageMs ?? Infinity) - (b.averageMs ?? Infinity) || b.correct - a.correct
        : sort === 'Progress'
          ? (b.answeredCount ?? 0) - (a.answeredCount ?? 0) || b.correct - a.correct || b.score - a.score
          : 0
  )

  const me = room.players.find(p => p.isMe)
  const podium = [room.players[1], room.players[0], room.players[2]]
  const answeredCount = room.reveal?.answeredPlayers ?? room.players.filter(p => p.answeredCurrent).length
  const totalPlayers = room.reveal?.totalPlayers ?? room.players.length
  const allAnswered = totalPlayers > 0 && answeredCount >= totalPlayers

  const showLeaderboard = isStudent || room.phase === 'lobby' || isReveal || finished

  const renderLeaderboard = (compact = false) => {
    const sortOptions = isStudent && !finished ? ['Overall', 'Progress', 'Accuracy', 'Fastest'] : ['Overall', 'Accuracy', 'Fastest']
    return (
      <div className={compact ? 'rounded-2xl border border-[#dfd4f0] bg-[#fcfaff] p-4' : ''}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 font-display text-lg font-extrabold">
              <Icon name={room.phase === 'lobby' ? 'users' : 'trophy'} className="text-purple-700" />
              {room.phase === 'lobby'
                ? 'The curious crew'
                : isReveal
                  ? `Question ${room.questionIndex + 1} Standings`
                  : isStudent && !finished
                    ? 'Live Race Leaderboard'
                    : 'Leaderboard'}
              <span className="rounded-full bg-purple-100 px-2.5 py-0.5 text-xs font-bold text-purple-800">{room.players.length} players</span>
            </h3>
            {isStudent && room.phase === 'playing' && (
              <p className="mt-1 text-xs text-[#6f5d80]">Live standings update as players pull ahead — click any player to inspect their stats.</p>
            )}
            {isReveal && (
              <p className="mt-1 text-xs text-[#6f5d80]">Interactive standings after Question {room.questionIndex + 1} — click a player row for question breakdown.</p>
            )}
          </div>
          {room.phase !== 'lobby' && (
            <div role="tablist" aria-label="Leaderboard ranking" className="flex flex-wrap rounded-xl bg-[#eee8f5] p-1">
              {sortOptions.map(t => (
                <button
                  key={t}
                  onClick={() => setSort(t)}
                  role="tab"
                  aria-selected={sort === t}
                  className={`min-h-10 rounded-lg px-3 text-xs font-bold sm:text-sm ${sort === t ? 'bg-white text-purple-800 shadow-sm' : 'text-[#75627f]'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>

        {isStudent && room.phase === 'playing' && room.players.length > 0 && (
          <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border border-[#e3d7f5] bg-gradient-to-r from-[#f3ecff] to-[#fff7e8] px-3.5 py-2.5 text-xs">
            <span className="inline-flex items-center gap-1 rounded-md bg-[#7842d9] px-2 py-0.5 font-extrabold text-white">
              <Icon name="trophy" className="h-3.5 w-3.5" /> IN FRONT
            </span>
            <span className="font-bold text-[#3f2c56]">
              {room.players[0].name}
            </span>
            <span className="text-[#6f5d80]">
              leads with {room.players[0].correct} correct ({room.players[0].answeredCount}/{room.total} answered • {room.players[0].score.toLocaleString()} pts)
            </span>
            {me && room.players[0].id !== me.id && (
              <span className="ml-auto font-semibold text-purple-800">
                You are #{room.players.findIndex(p => p.id === me.id) + 1}
              </span>
            )}
          </div>
        )}

        {room.players.length ? (
          <div className="mt-3 overflow-x-auto rounded-2xl border border-[#e7dfef] bg-white">
            <table className="w-full min-w-[580px] text-left text-sm">
              <thead className="bg-[#f3eef8] text-[#776581]">
                <tr>
                  <th scope="col" className="px-3 py-3.5 text-xs font-bold">Rank / player</th>
                  {isStudent && <th scope="col" className="px-3 py-3.5 text-xs font-bold">Progress</th>}
                  {isReveal && <th scope="col" className="px-3 py-3.5 text-xs font-bold">This Q</th>}
                  <th scope="col" className="px-3 py-3.5 text-xs font-bold">Correct</th>
                  <th scope="col" className="px-3 py-3.5 text-xs font-bold">Accuracy</th>
                  <th scope="col" className="px-3 py-3.5 text-xs font-bold">Avg. time</th>
                  <th scope="col" className="px-3 py-3.5 text-xs font-bold">Points</th>
                </tr>
              </thead>
              <tbody>
                {ranked.map((p, i) => {
                  const delta = rankDeltas.get(p.id) || 0
                  const isSelected = selectedPlayerId === p.id
                  const leaderAhead = i > 0 ? ranked[i - 1] : null
                  return (
                    <>
                      <tr
                        key={p.id}
                        onClick={() => setSelectedPlayerId(isSelected ? null : p.id)}
                        className={`cursor-pointer border-t border-[#efeaf5] transition-colors hover:bg-[#f6f1fd] ${p.isMe ? 'bg-[#faf7ff]' : ''} ${i === 0 && room.phase !== 'lobby' ? 'bg-[#fffdf6]' : ''}`}
                      >
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-extrabold ${i === 0 && room.phase !== 'lobby' ? 'bg-[#ffdb8a] text-[#6c4c13]' : 'text-[#877096]'}`}>
                              {i + 1}
                            </span>
                            <Avatar n={p.avatar} skin={p.skin} accent={p.accent} className="h-10 w-10" />
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <p className="max-w-36 truncate font-bold">
                                  {p.name}
                                  {p.isMe && <span className="ml-1 text-xs text-purple-700">(you)</span>}
                                </p>
                                {delta > 0 && room.phase !== 'lobby' && (
                                  <span className="rounded bg-green-100 px-1.5 py-0.5 text-[11px] font-extrabold text-green-800" title={`Moved up ${delta} place${delta > 1 ? 's' : ''}`}>
                                    ▲{delta}
                                  </span>
                                )}
                                {delta < 0 && room.phase !== 'lobby' && (
                                  <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[11px] font-bold text-amber-800" title={`Dropped ${Math.abs(delta)} place${Math.abs(delta) > 1 ? 's' : ''}`}>
                                    ▼{Math.abs(delta)}
                                  </span>
                                )}
                              </div>
                              <div className="mt-0.5 flex flex-wrap items-center gap-2">
                                {i === 0 && room.phase !== 'lobby' && (
                                  <span className="text-[11px] font-bold text-[#97651b]">★ Leading the pack</span>
                                )}
                                {p.fastestWins > 0 && (
                                  <span className="flex items-center gap-1 text-xs font-bold text-[#97651b]">
                                    <Icon name="bolt" className="h-3 w-3" />{p.fastestWins} fastest
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                        {isStudent && (
                          <td className="px-3 py-3">
                            <div className="w-28">
                              <div className="flex items-center justify-between text-[11px] font-bold text-[#685778]">
                                <span>{p.isDone ? 'Finished' : `Q${Math.min(room.total, p.answeredCount + 1)}/${room.total}`}</span>
                                <span>{p.answeredCount}/{room.total}</span>
                              </div>
                              <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-[#ebe3f5]">
                                <div
                                  className={`h-full rounded-full transition-all duration-300 ${p.isDone ? 'bg-green-600' : 'bg-[#7842d9]'}`}
                                  style={{ width: `${room.total ? Math.round((p.answeredCount / room.total) * 100) : 0}%` }}
                                />
                              </div>
                            </div>
                          </td>
                        )}
                        {isReveal && (
                          <td className="px-3 py-3">
                            {p.correctCurrent === true ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-bold text-green-800">
                                <Icon name="check" className="h-3.5 w-3.5" /> +{p.pointsCurrent?.toLocaleString()}
                              </span>
                            ) : p.answeredCurrent ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-bold text-red-800">
                                Missed
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600">
                                No answer
                              </span>
                            )}
                          </td>
                        )}
                        <td className="px-3 py-3 font-semibold text-[#4a7053]">{p.correct}</td>
                        <td className="px-3 py-3">{p.accuracy}%</td>
                        <td className="whitespace-nowrap px-3 py-3 text-[#73627d]">{time(p.averageMs)}</td>
                        <td className="whitespace-nowrap px-3 py-3 font-bold text-purple-800">{p.score.toLocaleString()}</td>
                      </tr>
                      {isSelected && (
                        <tr key={`${p.id}-details`} className="border-t border-[#efeaf5] bg-[#f7f2ff]">
                          <td colSpan={isStudent || isReveal ? 6 : 5} className="px-4 py-3 text-xs text-[#544266]">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <span>
                                <strong>{p.name}</strong>: {p.correct} of {p.answeredCount} answered correctly • Fastest answer: <strong>{time(p.fastestMs)}</strong> • Average speed: <strong>{time(p.averageMs)}</strong>
                              </span>
                              {leaderAhead ? (
                                <span className="font-semibold text-purple-800">
                                  {leaderAhead.correct > p.correct
                                    ? `${leaderAhead.correct - p.correct} correct answer${leaderAhead.correct - p.correct > 1 ? 's' : ''} behind ${leaderAhead.name}`
                                    : `${Math.max(0, leaderAhead.score - p.score).toLocaleString()} pts behind ${leaderAhead.name}`}
                                </span>
                              ) : (
                                <span className="font-bold text-[#8a601b]">Currently #1 in front!</span>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  )
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="mt-4 rounded-xl border border-dashed border-purple-200 p-6 text-center text-sm leading-6 text-slate-600">
            Waiting for players… Share your code and watch the crew arrive.
          </p>
        )}

        {room.phase !== 'lobby' && (
          <p className="mt-3 text-xs leading-5 text-[#786b80]">
            {sort === 'Overall'
              ? 'Ranked by correct answers, then speed-adjusted points, then average time.'
              : sort === 'Progress'
                ? 'Ranked by questions completed, then correct answers.'
                : sort === 'Accuracy'
                  ? 'Accuracy reflects questions opened/answered so far.'
                  : 'Fastest ranks timed submissions by average response time.'}{' '}
            Up to +500 speed points per correct answer during the first 30 seconds.
          </p>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className={`relative overflow-hidden rounded-2xl p-6 text-center ${finished ? 'bg-[#2d2242] text-white' : 'bg-[#eee7fa] text-[#47325f]'}`}>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <p className={`text-sm font-semibold ${finished ? 'text-[#e2d6f1]' : 'text-[#72518e]'}`}>{room.title}</p>
          <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-extrabold uppercase tracking-wider ${finished ? 'bg-white/15 text-[#eed7a1]' : 'bg-white text-[#7842d9]'}`}>
            {isStudent ? 'Student-paced' : 'Host-paced'}
          </span>
        </div>

        <p className={`mt-3 text-xs font-bold uppercase tracking-[.16em] ${finished ? 'text-[#eed7a1]' : 'text-[#755e89]'}`}>
          {room.phase === 'lobby'
            ? 'Join this website with game code'
            : finished
              ? 'The champions of curiosity'
              : isReveal
                ? `Question ${room.questionIndex + 1} of ${room.total} • Answer Revealed`
                : isStudent && room.host
                  ? `Live Student-Paced Session • ${room.total} Questions`
                  : isStudent && room.studentFinished
                    ? `All ${room.total} Questions Completed!`
                    : `Question ${room.questionIndex + 1} of ${room.total}`}
        </p>

        {room.phase === 'lobby' && (
          <>
            <p className="mt-3 font-display text-4xl font-extrabold tracking-[.15em] text-purple-800 sm:text-5xl">{room.code}</p>
            <button onClick={onCopy} className="mt-4 min-h-11 rounded-xl border border-purple-200 bg-white px-4 text-sm font-bold text-purple-800">
              Copy game code
            </button>
            <p className="mt-4 text-sm leading-6 text-[#705e80]">
              {isStudent
                ? 'Players answer all questions at their own speed with a live race leaderboard always visible.'
                : 'Everyone answers together; the host stops each question, reveals the answer, and shows the leaderboard.'}
            </p>
          </>
        )}

        {room.phase === 'playing' && !isStudent && (
          <>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <span className="flex min-h-9 items-center gap-2 rounded-full bg-white px-3 text-sm font-bold text-[#704591]">
                <Icon name="clock" className="h-4 w-4" />
                {countdown ? `Get ready… ${countdown}` : elapsed !== null ? `${(Math.max(0, elapsed) / 1000).toFixed(1)}s elapsed` : 'Host-paced question'}
              </span>
              <span className={`flex min-h-9 items-center gap-1.5 rounded-full px-3 text-sm font-bold ${allAnswered ? 'bg-green-100 text-green-900' : 'bg-white text-[#524360]'}`}>
                <Icon name="users" className="h-4 w-4" />
                {answeredCount}/{totalPlayers} answered
              </span>
            </div>
            <h3 className="mt-4 font-display text-xl font-extrabold leading-8">{countdown ? 'Curious minds, ready?' : room.question?.text}</h3>
          </>
        )}

        {room.phase === 'playing' && isStudent && !room.host && !room.studentFinished && (
          <>
            <div className="mt-4 flex justify-center">
              <span className="flex min-h-9 items-center gap-2 rounded-full bg-white px-3 text-sm font-bold text-[#704591]">
                <Icon name="clock" className="h-4 w-4" />
                {countdown ? `Get ready… ${countdown}` : elapsed !== null ? `${(Math.max(0, elapsed) / 1000).toFixed(1)}s on this question` : 'Your pace'}
              </span>
            </div>
            <h3 className="mt-4 font-display text-xl font-extrabold leading-8">{countdown ? 'Curious minds, ready?' : room.question?.text}</h3>
          </>
        )}

        {room.phase === 'playing' && isStudent && (room.host || room.studentFinished) && (
          <>
            <h3 className="mt-3 font-display text-xl font-extrabold leading-8">
              {room.host ? 'Students are racing through the quiz!' : 'You finished! Watch the live standings below.'}
            </h3>
            <p className="mt-2 text-sm text-[#6b587c]">
              {room.host
                ? `${room.players.filter(p => p.isDone).length} of ${room.players.length} players have finished all ${room.total} questions.`
                : 'Waiting for remaining players to finish or the host to wrap up the session.'}
            </p>
          </>
        )}

        {isReveal && (
          <>
            <h3 className="mt-4 font-display text-xl font-extrabold leading-8">{room.question?.text}</h3>
            {room.reveal && room.question && room.reveal.correctIndex >= 0 && (
              <p className="mt-2 inline-flex items-center gap-2 rounded-full bg-green-100 px-4 py-1.5 text-sm font-extrabold text-green-900">
                <Icon name="check" className="h-4 w-4" />
                Correct answer: {String.fromCharCode(65 + room.reveal.correctIndex)}. {room.question.options[room.reveal.correctIndex]}
              </p>
            )}
          </>
        )}

        {finished && (
          <>
            <Icon name="trophy" className="mx-auto mt-4 h-9 w-9 text-[#ffdb8a]" />
            <h3 className="mt-3 font-display text-2xl font-extrabold">Every answer. Every second.</h3>
            <p className="mt-2 text-sm text-[#ded0ee]">A little friendly competition. A lot to celebrate.</p>
          </>
        )}
      </div>

      {room.phase === 'playing' && !isStudent && !countdown && (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            {room.question?.options.map((option, i) => (
              <button
                key={`${room.questionIndex}-${i}`}
                disabled={room.host || room.answered || busy}
                onClick={() => onAnswer(i)}
                className={`min-h-16 rounded-xl border p-4 text-left text-sm font-bold ${
                  room.selectedOption === i
                    ? 'border-purple-600 bg-purple-100 text-purple-900'
                    : room.answered
                      ? 'border-purple-200 bg-purple-50/60 text-purple-900/70'
                      : 'border-[#ddd1eb] bg-white text-[#524360] hover:bg-purple-50'
                }`}
              >
                <span className="mr-3 inline-flex h-7 w-7 items-center justify-center rounded-lg bg-purple-100 text-purple-800">
                  {String.fromCharCode(65 + i)}
                </span>
                {option}
              </button>
            ))}
          </div>
          {room.answered && !room.host && (
            <p role="status" className="text-center text-sm font-bold text-green-800">
              Answer locked in ({answeredCount}/{totalPlayers} answered). Waiting for the host to stop the question…
            </p>
          )}
          {room.host && (
            <div className="rounded-2xl border border-[#e3d9f2] bg-white p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                <span className="font-bold text-[#4a3761]">
                  {allAnswered ? 'Everyone has answered!' : `Waiting on answers: ${answeredCount} of ${totalPlayers} players answered`}
                </span>
                <span className="text-xs font-semibold text-[#75627f]">
                  {totalPlayers ? `${Math.round((answeredCount / totalPlayers) * 100)}% submitted` : 'No players yet'}
                </span>
              </div>
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-[#eee8f5]">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${allAnswered ? 'bg-green-600' : 'bg-[#7842d9]'}`}
                  style={{ width: `${totalPlayers ? Math.round((answeredCount / totalPlayers) * 100) : 0}%` }}
                />
              </div>
            </div>
          )}
        </>
      )}

      {isReveal && room.question && room.reveal && (
        <div className="grid gap-3 sm:grid-cols-2">
          {room.question.options.map((option, i) => {
            const isCorrect = i === room.reveal!.correctIndex
            const isMine = room.selectedOption === i
            const count = room.reveal!.optionCounts[i] ?? 0
            const pct = totalPlayers > 0 ? Math.round((count / totalPlayers) * 100) : 0
            return (
              <div
                key={`reveal-${room.questionIndex}-${i}`}
                className={`relative overflow-hidden rounded-xl border p-4 text-sm font-bold ${
                  isCorrect
                    ? 'border-green-600 bg-green-50 text-green-950'
                    : isMine
                      ? 'border-red-400 bg-red-50 text-red-950'
                      : 'border-[#e2d9ee] bg-white text-[#524360]'
                }`}
              >
                <div className="relative z-10 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className={`inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${isCorrect ? 'bg-green-600 text-white' : isMine ? 'bg-red-600 text-white' : 'bg-purple-100 text-purple-800'}`}>
                      {isCorrect ? <Icon name="check" className="h-4 w-4" /> : String.fromCharCode(65 + i)}
                    </span>
                    <span>{option}</span>
                  </div>
                  <span className="shrink-0 text-xs font-extrabold">
                    {count} ({pct}%)
                  </span>
                </div>
                {isMine && (
                  <p className="relative z-10 mt-1.5 pl-9 text-xs font-semibold">
                    {isCorrect ? 'Your answer — spot on!' : 'Your answer'}
                  </p>
                )}
              </div>
            )
          })}
        </div>
      )}

      {room.phase === 'playing' && isStudent && !room.host && !room.studentFinished && !countdown && (
        <div className="grid gap-3 sm:grid-cols-2">
          {room.question?.options.map((option, i) => (
            <button
              key={`student-${room.questionIndex}-${i}`}
              disabled={busy}
              onClick={() => onAnswer(i)}
              className="min-h-16 rounded-xl border border-[#ddd1eb] bg-white p-4 text-left text-sm font-bold text-[#524360] transition hover:border-[#7842d9] hover:bg-purple-50 disabled:opacity-60"
            >
              <span className="mr-3 inline-flex h-7 w-7 items-center justify-center rounded-lg bg-purple-100 text-purple-800">
                {String.fromCharCode(65 + i)}
              </span>
              {option}
            </button>
          ))}
        </div>
      )}

      {finished && room.players.length > 0 && (
        <div className="grid grid-cols-3 items-end gap-2 pt-4 sm:gap-4" aria-label="Overall top three">
          {podium.map((p, i) =>
            p ? (
              <div key={p.id} className="min-w-0 text-center">
                <div className={`mx-auto mb-3 w-fit ${i === 1 ? '-translate-y-2' : ''}`}>
                  <Avatar n={p.avatar} skin={p.skin} accent={p.accent} className={`${i === 1 ? 'h-20 w-20' : 'h-16 w-16'} mx-auto`} />
                </div>
                <p className="truncate px-1 text-sm font-bold">{p.name}</p>
                <p className="mt-1 text-xs text-[#72617e]">{p.correct}/{room.total} correct</p>
                <div
                  className={`mt-3 flex flex-col items-center rounded-t-2xl border p-3 ${
                    i === 1
                      ? 'min-h-32 border-[#e9cd8f] bg-[#fff1d2] text-[#806029]'
                      : i === 0
                        ? 'min-h-24 border-[#ded3eb] bg-[#ece6f5] text-[#68527c]'
                        : 'min-h-20 border-[#e9cdbb] bg-[#f7e9dd] text-[#855e43]'
                  }`}
                >
                  <span className="font-display text-2xl font-extrabold">{[2, 1, 3][i]}</span>
                  <span className="mt-1 text-xs font-bold sm:text-sm">{p.score.toLocaleString()} pts</span>
                </div>
              </div>
            ) : (
              <div key={`empty-${i}`} />
            )
          )}
        </div>
      )}

      {me && room.phase !== 'lobby' && (
        <div className="grid grid-cols-3 gap-2 rounded-2xl border border-[#e5dcee] bg-white p-4 text-center">
          {[
            [`${me.correct}/${room.total}`, 'Your correct answers'],
            [time(me.averageMs), 'Average response'],
            [time(me.fastestMs), 'Your fastest answer'],
          ].map(([value, label]) => (
            <div key={label}>
              <p className="font-display text-lg font-extrabold text-purple-800">{value}</p>
              <p className="mt-1 text-xs text-[#72657b]">{label}</p>
            </div>
          ))}
        </div>
      )}

      {showLeaderboard && renderLeaderboard(isStudent && room.phase === 'playing' && !room.host && !room.studentFinished)}

      {finished && (
        <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-[#ead8ad] bg-[#fff6e4] p-5">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-[#a57828]">
            <Icon name="coin" className="h-6 w-6" />
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-extrabold text-[#74552b]">
              {room.rewardClaimed
                ? 'Coins added to your account!'
                : room.rewardEligible && room.rewardCoins
                  ? `Your game earned ${room.rewardCoins} coins`
                  : 'Your next legendary look is waiting.'}
            </h3>
            <p className="mt-1 text-sm leading-6 text-[#806b49]">
              {room.rewardEligible
                ? 'Playing + correct answers + fastest correct answers + podium bonus.'
                : 'Join your next live game while signed in to earn permanent shop coins.'}
            </p>
          </div>
          {room.rewardEligible && room.rewardCoins > 0 && !room.rewardClaimed ? (
            <button disabled={busy} onClick={onClaim} className={button}>
              Claim {room.rewardCoins} coins
            </button>
          ) : (
            <button onClick={onShop} className="min-h-11 text-sm font-bold text-[#795223]">
              Visit avatar shop <span aria-hidden="true">↗</span>
            </button>
          )}
        </div>
      )}

      {error && (
        <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">
          {error}
        </p>
      )}

      {room.host && !finished && !isStudent && (
        <>
          {room.phase === 'lobby' && (
            <button disabled={busy} onClick={onNext} className={`${button} w-full`}>
              Start the game
              <Icon name="arrow" />
            </button>
          )}
          {room.phase === 'playing' && (
            <button disabled={busy} onClick={onReveal} className={`${button} w-full`}>
              {allAnswered ? 'Stop question & show answer' : `Stop question & show answer (${answeredCount}/${totalPlayers} answered)`}
              <Icon name="arrow" />
            </button>
          )}
          {isReveal && (
            <button disabled={busy} onClick={onNext} className={`${button} w-full`}>
              {room.questionIndex + 1 >= room.total ? 'Reveal the podium' : 'Next question'}
              <Icon name="arrow" />
            </button>
          )}
        </>
      )}

      {room.host && !finished && isStudent && (
        <button disabled={busy} onClick={onNext} className={`${button} w-full`}>
          {room.phase === 'lobby' ? 'Start student-paced game' : 'End game & reveal podium'}
          <Icon name="arrow" />
        </button>
      )}

      {finished && (
        <button onClick={onClose} className={`${button} w-full`}>
          Find the next adventure
          <Icon name="arrow" />
        </button>
      )}

      <p className="text-center text-xs text-[#796782]">
        {isStudent
          ? 'Live updates every few seconds. Players advance at their own pace while the leaderboard tracks who is in front.'
          : 'Live updates every few seconds. Host stops each question to reveal the answer and standings.'}
      </p>
    </div>
  )
}
