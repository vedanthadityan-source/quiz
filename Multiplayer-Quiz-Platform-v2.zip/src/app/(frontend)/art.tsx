import DeluxeAvatar, { type SkinLook } from './deluxe-avatar'

export function Icon({ name, className = '' }: { name: string; className?: string }) {
  const paths: Record<string, string> = {
    search: 'm21 21-5-5 M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0',
    discover: 'm16 8-3 5-5 3 3-5 5-3 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
    library: 'M4 4h5v16H4z M12 4h3v16h-3z M18 4l4 15-3 1-4-15',
    saved: 'M6 3h12v18l-6-4-6 4z',
    plus: 'M12 5v14 M5 12h14',
    arrow: 'M5 12h14 m-5-5 5 5-5 5',
    chevron: 'm9 5 7 7-7 7',
    users: 'M16 21v-3a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v3 M18 8a3 3 0 0 1 0 6 M22 21v-3a4 4 0 0 0-3-4 M13 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
    play: 'm8 4 13 8-13 8z',
    bolt: 'm13 2-9 12h7l-1 8 10-12h-7z',
    close: 'm6 6 12 12 M6 18 18 6',
    globe: 'M22 12H2 M12 2c6 6 6 14 0 20-6-6-6-14 0-20 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
    trophy: 'M8 3h8v7a4 4 0 0 1-8 0z M8 5H3v3a5 5 0 0 0 5 5 M16 5h5v3a5 5 0 0 1-5 5 M12 14v7 M7 21h10',
    help: 'M9 9a3 3 0 1 1 5 2c-2 1-2 2-2 3 M12 17h.01 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
    check: 'm5 12 4 4L19 6',
    edit: 'm15 4 5 5 M4 20l5-1L21 7l-5-5L4 14z',
    clock: 'M12 6v6l4 2 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
    logout: 'M9 3H4v18h5 M10 12h12 m-5-5 5 5-5 5',
    shop: 'M3 9h18l-2-6H5L3 9Zm1 1v11h16V10M9 21v-7h6v7M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0',
    coin: 'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0M15 8h-4a2 2 0 0 0 0 4h2a2 2 0 0 1 0 4H9M12 6v2m0 8v2',
    lock: 'M6 10h12v11H6zM8 10V6a4 4 0 0 1 8 0v4M12 14v3',
  }
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className={`h-5 w-5 shrink-0 ${className}`} aria-hidden="true"><path d={paths[name] || paths.discover} /></svg>
}

export const avatarNames = ['Mochi', 'Sprout', 'Bubbles', 'Cosmo', 'Peaches', 'Ziggy', 'Pip', 'Sunny', 'Orbit', 'Bean', 'Mint', 'Berry']
const fills = ['#b1a0f6', '#a8d7a5', '#f7c479', '#8dc7e7', '#ed9fae', '#c1b0ef', '#edb575', '#f4d46c', '#9fa9e4', '#c8a284', '#92cebc', '#d6a5d7']

export function Avatar({ n, className = 'h-12 w-12', skin, accent }: { n: number; className?: string; skin?: SkinLook | null; accent?: string }) {
  if (skin) return <DeluxeAvatar skin={skin} accent={accent} className={className} />
  const i = ((n % 12) + 12) % 12
  return <svg viewBox="0 0 100 100" className={`shrink-0 ${className}`} role="img" aria-label={`${avatarNames[i]} avatar`}>
    <rect width="100" height="100" rx="30" fill={fills[i]} />
    {i % 3 === 0 ? <><path d="M20 62V40Q20 15 48 24Q78 12 81 42V65Z" fill="#fff4dc" /><path d="m29 30-5-16 19 12m19 0 14-13-1 23" fill="#fff4dc" /></> : i % 3 === 1 ? <><path d="M22 61Q12 32 34 31Q49 9 65 30Q88 32 78 64Z" fill="#327954" /><ellipse cx="50" cy="58" rx="27" ry="24" fill="#e5f2be" /></> : <><ellipse cx="50" cy="49" rx="31" ry="29" fill="#fff1d4" /><path d="M21 39Q17 15 36 22M66 23Q88 14 80 40" fill="#a46047" /></>}
    <ellipse cx="39" cy="50" rx="4" ry="6" fill="#282238" /><ellipse cx="62" cy="50" rx="4" ry="6" fill="#282238" />
    <path d="M44 63q7 7 14-1" fill="none" stroke="#282238" strokeWidth="3" strokeLinecap="round" />
    <ellipse cx="29" cy="60" rx="6" ry="3" fill="#ed9fae" /><ellipse cx="72" cy="60" rx="6" ry="3" fill="#ed9fae" />
    {i > 5 && <path d="m35 22 6-13 9 9 10-9 6 14" fill="#ffd461" stroke="#bd8530" strokeWidth="2" />}
    <path d="M23 100q0-26 27-26t28 26" fill={i % 2 ? '#546153' : '#6b50a5'} />
  </svg>
}

export function QuizArt({ kind, hero = false }: { kind: string; hero?: boolean }) {
  const colors: Record<string, string> = { space: '#22204b', earth: '#bce4e2', science: '#e4d8fa', math: '#ffe2b1', history: '#f3d2b8', tech: '#cfdffc' }
  return <svg viewBox="0 0 440 230" preserveAspectRatio="xMidYMid slice" className="h-full w-full" aria-hidden="true">
    <rect width="440" height="230" fill={colors[kind] || colors.space} />
    {kind === 'space' ? <>
      {[25, 76, 130, 185, 260, 310, 375, 413].map((x, i) => <path key={x} d={`M${x} ${22 + i % 3 * 55}v8m-4-4h8`} stroke={i % 2 ? '#c6b9f3' : '#f9d77d'} strokeWidth="2" />)}
      <circle cx="335" cy="75" r="48" fill="#f0a05d" /><path d="M290 71q43-18 88 5M291 87q44-19 85 6" fill="none" stroke="#d77948" strokeWidth="9" />
      <ellipse cx="333" cy="84" rx="80" ry="13" transform="rotate(-25 333 84)" fill="none" stroke="#f8cf85" strokeWidth="10" />
      <circle cx="89" cy="180" r="57" fill="#7475c9" /><path d="M40 173q51-26 101 8" fill="none" stroke="#9598e3" strokeWidth="14" />
      <g transform="translate(160 38) rotate(20 50 70)"><path d="M30 137 12 168l40-13 33 7-12-40" fill="#e88678" /><path d="M31 125Q8 69 56 8q52 58 27 117Z" fill="#fff5e1" /><path d="m38 32 18-24 21 26" fill="#ed9d8d" /><circle cx="57" cy="69" r="18" fill="#818ed6" stroke="#d1d4f4" strokeWidth="6" /><path d="m42 134 15 43 16-43" fill="#ffd986" /></g>
    </> : kind === 'earth' ? <>
      <circle cx="230" cy="120" r="91" fill="#4d9bc5" /><path d="m172 48 41-15 31 18-15 25-34 3-5 23-35-3m84-5 45-11 24 25-15 28-17 3-11 44-30 22-16-47-25-24z" fill="#a1cf89" />
      <path d="M125 128Q46 198 121 201q145 6 229-85" fill="none" stroke="#fff9dc" strokeWidth="5" strokeDasharray="8 7" />
      <path d="m335 83 28 23-31 11 9-16-6-18" fill="#f68d69" /><path d="m76 42 7 15 17 3-13 11 1 18-14-9-16 5 5-17-9-14 18 1z" fill="#f9da82" />
    </> : kind === 'science' ? <>
      <ellipse cx="211" cy="111" rx="121" ry="42" transform="rotate(-30 211 111)" fill="none" stroke="#9d81d0" strokeWidth="5" /><ellipse cx="211" cy="111" rx="121" ry="42" transform="rotate(40 211 111)" fill="none" stroke="#9d81d0" strokeWidth="5" /><ellipse cx="211" cy="111" rx="42" ry="99" fill="none" stroke="#9d81d0" strokeWidth="5" />
      <circle cx="211" cy="111" r="24" fill="#f7b669" /><circle cx="105" cy="163" r="12" fill="#738ecd" /><circle cx="242" cy="49" r="12" fill="#e28a9f" /><circle cx="311" cy="156" r="12" fill="#87b89b" />
      <path d="M340 146v-35h29v35l29 53h-88Z" fill="#fff9f0" stroke="#8761b0" strokeWidth="4" /><path d="m323 181 66 0 10 18h-89z" fill="#a1ceb5" />
    </> : kind === 'math' ? <>
      <g transform="rotate(-12 205 110)"><rect x="142" y="30" width="127" height="174" rx="17" fill="#fff8e6" stroke="#d9a963" strokeWidth="3" /><rect x="157" y="46" width="97" height="39" rx="6" fill="#c6d9c1" />{[0, 1, 2].map(i => [0, 1, 2].map(j => <rect key={`${i}${j}`} x={158 + i * 34} y={101 + j * 29} width="25" height="21" rx="5" fill={i === 2 ? '#e9986b' : '#e9d9b7'} />))}</g><text x="52" y="88" fontSize="55" fill="#b87e3d">÷</text><text x="316" y="170" fontSize="74" fill="#d79556">×</text><text x="300" y="65" fontSize="45" fill="#b87e3d">+</text>
    </> : kind === 'history' ? <>
      <circle cx="314" cy="63" r="36" fill="#ffe5a8" /><path d="m70 205 110-155 117 155z" fill="#cf9c6b" /><path d="m180 50 20 155h97z" fill="#b68155" /><path d="m242 205 71-99 75 99z" fill="#dbae7b" /><path d="M43 205h360" stroke="#a8734f" strokeWidth="4" /><path d="M84 64h33m-16-13v26" stroke="#fff5df" strokeWidth="4" />
    </> : <>
      <rect x="105" y="35" width="231" height="145" rx="12" fill="#5b77ac" /><rect x="116" y="46" width="209" height="122" rx="5" fill="#25344e" /><path d="m169 86-24 21 24 20m100-41 24 21-24 20m-59-52-20 67" fill="none" stroke="#9bd7ce" strokeWidth="7" strokeLinecap="round" /><path d="m105 181-35 23h302l-36-23" fill="#8eabe0" /><path d="M191 184h61l9 10h-79z" fill="#bad0f3" />
    </>}
    {hero && <rect width="440" height="230" fill="none" stroke="#fff" strokeWidth="0" />}
  </svg>
}
