import { APIError, type CollectionConfig } from 'payload'
import { rewardFor, standings, type GameQuestion } from '../lib/game-scoring'

export const AvatarSkins: CollectionConfig = {
  slug: 'avatar-skins',
  admin: { useAsTitle: 'name', group: 'Avatar shop' },
  access: {
    read: () => true,
    create: ({ req }) => req.user?.collection === 'admins',
    update: ({ req }) => req.user?.collection === 'admins',
    delete: () => false,
  },
  fields: [
    { name: 'name', type: 'text', required: true, maxLength: 60 },
    { name: 'sku', type: 'text', required: true, unique: true, index: true },
    { name: 'description', type: 'textarea', maxLength: 240 },
    { name: 'variant', type: 'select', required: true, options: ['dragon', 'ninja', 'robot', 'cosmic', 'phoenix', 'royal'] },
    { name: 'rarity', type: 'select', required: true, options: ['Rare', 'Epic', 'Legendary'] },
    { name: 'price', type: 'number', required: true, min: 1, max: 100000, validate: (value: unknown) => Number.isInteger(value) || 'Use a whole coin price.' },
    { name: 'active', type: 'checkbox', defaultValue: true },
  ],
}

// Append-only events avoid read/modify/write balance races. A unique per-owner
// sequence lets one concurrent spend win; other requests retry from a fresh balance.
export const WalletEvents: CollectionConfig = {
  slug: 'wallet-events',
  admin: { useAsTitle: 'operationKey', group: 'Avatar shop' },
  access: {
    create: ({ req }) => req.context.walletServer === true && req.user?.collection === 'users',
    read: ({ req }) => req.user?.collection === 'users' ? { owner: { equals: req.user.id } } : false,
    update: () => false,
    delete: () => false,
  },
  hooks: {
    beforeValidate: [async ({ data, req }) => {
      if (!data || !req.user || req.user.collection !== 'users' || req.context.walletServer !== true) throw new APIError('Please sign in to use your wallet.', 403)
      const user = req.user
      const previous = await req.payload.find({ collection: 'wallet-events', user, req, overrideAccess: false, depth: 0, sort: '-sequence', limit: 1 })
      const last = previous.docs[0]
      let amount = 0
      let operationKey = ''
      if (data.kind === 'purchase') {
        const skin = await req.payload.findByID({ collection: 'avatar-skins', id: data.skin, req, user, overrideAccess: false, depth: 0 })
        if (!skin.active) throw new APIError('That avatar is not currently available.', 400)
        amount = -skin.price
        operationKey = `purchase:${user.id}:${skin.id}`
        data.room = null
      } else if (data.kind === 'reward') {
        const room = await req.payload.findByID({ collection: 'game-rooms', id: data.room, req, context: { gameServer: true }, user, overrideAccess: false, depth: 0 })
        if (room.phase !== 'finished') throw new APIError('Finish the game before claiming coins.', 400)
        const players = await req.payload.find({ collection: 'game-players', req, context: { gameServer: true }, user, overrideAccess: false, where: { room: { equals: room.id } }, limit: 100, depth: 0 })
        const player = players.docs.find(p => p.account === user.id)
        if (!player) throw new APIError('Join the game while signed in to earn account coins.', 403)
        const ranks = standings(players.docs, room.questions as GameQuestion[], (room.questions as GameQuestion[]).length)
        const rank = ranks.findIndex(p => p.id === player.id)
        amount = rewardFor(ranks[rank], rank)
        if (!amount) throw new APIError('Answer at least one question to earn coins.', 400)
        operationKey = `reward:${user.id}:${room.id}`
        data.skin = null
      } else throw new APIError('Invalid wallet event.', 400)
      const existing = await req.payload.find({ collection: 'wallet-events', req, user, overrideAccess: false, where: { operationKey: { equals: operationKey } }, limit: 1 })
      if (existing.docs.length) throw new APIError(data.kind === 'purchase' ? 'You already own this avatar.' : 'These coins have already been claimed.', 409)
      const balance = (last?.balanceAfter ?? 300) + amount
      if (balance < 0) throw new APIError('Not enough coins. Play live games to earn more.', 400)
      const sequence = (last?.sequence ?? 0) + 1
      return { ...data, owner: user.id, amount, balanceAfter: balance, sequence, sequenceKey: `${user.id}:${sequence}`, operationKey }
    }],
  },
  fields: [
    { name: 'owner', type: 'relationship', relationTo: 'users', required: true, index: true },
    { name: 'kind', type: 'select', required: true, options: ['purchase', 'reward'] },
    { name: 'skin', type: 'relationship', relationTo: 'avatar-skins' },
    { name: 'room', type: 'relationship', relationTo: 'game-rooms' },
    { name: 'amount', type: 'number', required: true },
    { name: 'balanceAfter', type: 'number', required: true, min: 0 },
    { name: 'sequence', type: 'number', required: true, index: true },
    { name: 'sequenceKey', type: 'text', required: true, unique: true },
    { name: 'operationKey', type: 'text', required: true, unique: true, index: true },
  ],
}
