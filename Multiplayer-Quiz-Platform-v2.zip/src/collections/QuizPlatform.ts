import { APIError, type Access, type CollectionConfig, type Where } from 'payload'

const appUser: Access = ({ req }) => req.user?.collection === 'users'
const own: Access = ({ req }) => req.user?.collection === 'users' ? { owner: { equals: req.user.id } } : false
const internal: Access = ({ req }) => req.context.gameServer === true

export const Users: CollectionConfig = {
  slug: 'users',
  auth: true,
  admin: { useAsTitle: 'name', group: 'Quiz community' },
  access: {
    create: () => true,
    read: ({ req }) => req.user?.collection === 'users' ? { id: { equals: req.user.id } } : false,
    update: ({ req }) => req.user?.collection === 'users' ? { id: { equals: req.user.id } } : false,
    delete: () => false,
    admin: () => false,
  },
  hooks: {
    beforeChange: [async ({ data, req }) => {
      if (data.equippedSkin && req.user?.collection === 'users') {
        const owned = await req.payload.find({
          collection: 'wallet-events', req, user: req.user, overrideAccess: false, depth: 0, limit: 1,
          where: { and: [{ kind: { equals: 'purchase' } }, { skin: { equals: data.equippedSkin } }] },
        })
        if (!owned.docs.length) throw new APIError('Unlock this avatar in the shop first.', 403)
      }
      return data
    }],
  },
  fields: [
    { name: 'name', type: 'text', required: true, maxLength: 40 },
    { name: 'avatar', type: 'number', defaultValue: 0, min: 0, max: 11 },
    { name: 'equippedSkin', type: 'relationship', relationTo: 'avatar-skins', access: { create: () => false } },
    { name: 'avatarAccent', type: 'select', options: ['violet', 'mint', 'sunset', 'ice'], defaultValue: 'violet' },
  ],
}

export const Quizzes: CollectionConfig = {
  slug: 'quizzes',
  admin: { useAsTitle: 'title', group: 'Quiz community' },
  versions: { drafts: true },
  access: {
    create: appUser,
    read: ({ req }): Where => req.user?.collection === 'users'
      ? { or: [{ _status: { equals: 'published' } }, { owner: { equals: req.user.id } }] }
      : { _status: { equals: 'published' } },
    update: own,
    delete: own,
  },
  hooks: {
    beforeChange: [({ data, req, operation }) => {
      if (operation === 'create' && req.user?.collection === 'users') data.owner = req.user.id
      return data
    }],
  },
  fields: [
    { name: 'title', type: 'text', required: true, maxLength: 100 },
    { name: 'description', type: 'textarea', maxLength: 500 },
    { name: 'subject', type: 'select', required: true, options: ['Science', 'Mathematics', 'Geography', 'History', 'English', 'Technology', 'General knowledge'] },
    { name: 'art', type: 'select', defaultValue: 'space', options: ['space', 'earth', 'science', 'math', 'history', 'tech'] },
    { name: 'authorName', type: 'text', defaultValue: 'Quizzo Studio', maxLength: 40 },
    { name: 'owner', type: 'relationship', relationTo: 'users', index: true, access: { create: () => false, update: () => false } },
    { name: 'questions', type: 'array', required: true, minRows: 1, maxRows: 50, fields: [
      { name: 'text', type: 'text', required: true, maxLength: 300 },
      { name: 'options', type: 'array', minRows: 4, maxRows: 4, required: true, fields: [{ name: 'text', type: 'text', required: true, maxLength: 150 }] },
      { name: 'correct', type: 'number', min: 0, max: 3, required: true },
    ] },
  ],
}

export const Rooms: CollectionConfig = {
  slug: 'game-rooms',
  admin: { useAsTitle: 'code', group: 'Live games' },
  access: { create: internal, read: internal, update: internal, delete: () => false },
  fields: [
    { name: 'code', type: 'text', required: true, unique: true, index: true },
    { name: 'hostKey', type: 'text', required: true, hidden: true },
    { name: 'title', type: 'text', required: true },
    { name: 'questions', type: 'json', required: true },
    { name: 'pace', type: 'select', options: ['host', 'student'], defaultValue: 'host' },
    { name: 'phase', type: 'select', options: ['lobby', 'playing', 'reveal', 'finished'], defaultValue: 'lobby' },
    { name: 'questionIndex', type: 'number', defaultValue: 0 },
    { name: 'questionStartedAt', type: 'date' },
  ],
}

export const Players: CollectionConfig = {
  slug: 'game-players',
  admin: { useAsTitle: 'name', group: 'Live games' },
  access: { create: internal, read: internal, update: internal, delete: () => false },
  fields: [
    { name: 'room', type: 'relationship', relationTo: 'game-rooms', required: true, index: true },
    { name: 'key', type: 'text', hidden: true, required: true },
    { name: 'name', type: 'text', required: true, maxLength: 24 },
    { name: 'avatar', type: 'number', min: 0, max: 11, defaultValue: 0 },
    { name: 'score', type: 'number', defaultValue: 0 },
    { name: 'answers', type: 'json', defaultValue: [] },
    { name: 'currentQuestionIndex', type: 'number', defaultValue: 0 },
    { name: 'currentQuestionStartedAt', type: 'date' },
    { name: 'account', type: 'relationship', relationTo: 'users', index: true },
    { name: 'skin', type: 'relationship', relationTo: 'avatar-skins' },
    { name: 'accent', type: 'select', options: ['violet', 'mint', 'sunset', 'ice'] },
  ],
}
