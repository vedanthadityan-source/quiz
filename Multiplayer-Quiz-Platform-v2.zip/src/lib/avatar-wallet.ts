import 'server-only'
import { getPayload } from 'payload'
import config from '@payload-config'
import type { User } from '@/payload-types'

export async function walletView(user: (User & { collection: 'users' }) | null) {
  const payload = await getPayload({ config })
  const catalog = await payload.find({ collection: 'avatar-skins', overrideAccess: false, user, limit: 100, sort: 'price', depth: 0 })
  if (!user) return { catalog: catalog.docs.filter(s => s.active), coins: 0, owned: [], equipped: null, accent: 'violet', starter: false }
  const [events, purchases] = await Promise.all([
    payload.find({ collection: 'wallet-events', overrideAccess: false, user, limit: 1, depth: 0, sort: '-sequence' }),
    payload.find({ collection: 'wallet-events', overrideAccess: false, user, limit: 100, depth: 0, where: { kind: { equals: 'purchase' } } }),
  ])
  const profile = await payload.findByID({ collection: 'users', id: user.id, overrideAccess: false, user, depth: 0 })
  const equipped = typeof profile.equippedSkin === 'object' ? profile.equippedSkin?.id : profile.equippedSkin
  return {
    catalog: catalog.docs.filter(s => s.active || purchases.docs.some(e => e.skin === s.id)),
    coins: events.docs[0]?.balanceAfter ?? 300,
    owned: purchases.docs.map(e => typeof e.skin === 'object' ? e.skin?.id : e.skin),
    equipped: equipped || null, accent: profile.avatarAccent || 'violet', starter: events.docs.length === 0,
  }
}
