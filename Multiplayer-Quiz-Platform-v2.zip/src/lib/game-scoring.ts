export type GameQuestion = { text: string; options: { text: string }[]; correct: number }
export type GameAnswer = { index: number; option: number; durationMs?: number }
export type ScoringPlayer = {
  id: string | number
  name: string
  avatar?: number | null
  score?: number | null
  answers?: unknown
  currentQuestionIndex?: number | null
}

export function answerList(value: unknown): GameAnswer[] {
  if (!Array.isArray(value)) return []
  return value.filter((a): a is GameAnswer => a && Number.isInteger(a.index) && Number.isInteger(a.option))
}

export function pointsFor(correct: boolean, durationMs?: number) {
  return correct ? 1000 + (typeof durationMs === 'number' ? Math.max(0, 500 - Math.floor(durationMs / 60)) : 0) : 0
}

export function standings<T extends ScoringPlayer>(
  players: T[],
  questions: GameQuestion[],
  completed: number,
  options?: { studentPaced?: boolean }
) {
  const fastest = new Map<number, number>()
  for (const player of players) {
    for (const a of answerList(player.answers)) {
      if (questions[a.index]?.correct !== a.option || typeof a.durationMs !== 'number') continue
      fastest.set(a.index, Math.min(fastest.get(a.index) ?? Infinity, a.durationMs))
    }
  }
  return players.map(player => {
    const answers = answerList(player.answers)
    const correct = answers.filter(a => questions[a.index]?.correct === a.option).length
    const times = answers.flatMap(a => typeof a.durationMs === 'number' ? [a.durationMs] : [])
    const fastestWins = answers.filter(a => a.durationMs !== undefined && questions[a.index]?.correct === a.option && a.durationMs === fastest.get(a.index)).length
    const calculated = answers.reduce((sum, a) => sum + pointsFor(questions[a.index]?.correct === a.option, a.durationMs), 0)
    const playerCompleted = options?.studentPaced ? Math.max(answers.length, completed) : completed
    const currentProgress = Math.min(questions.length, Math.max(answers.length, player.currentQuestionIndex ?? 0))
    return {
      id: player.id,
      name: player.name,
      avatar: player.avatar || 0,
      score: answers.length ? calculated : player.score || 0,
      correct,
      answeredCount: answers.length,
      currentProgress,
      isDone: answers.length >= questions.length,
      accuracy: playerCompleted ? Math.round(correct / playerCompleted * 100) : 0,
      averageMs: times.length ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : null,
      fastestMs: times.length ? Math.min(...times) : null,
      fastestWins,
    }
  }).sort((a, b) => {
    if (options?.studentPaced) {
      return b.correct - a.correct || b.answeredCount - a.answeredCount || b.score - a.score || (a.averageMs ?? Infinity) - (b.averageMs ?? Infinity) || String(a.id).localeCompare(String(b.id))
    }
    return b.correct - a.correct || b.score - a.score || (a.averageMs ?? Infinity) - (b.averageMs ?? Infinity) || String(a.id).localeCompare(String(b.id))
  })
}

export function rewardFor(player: { correct: number; fastestWins: number; answeredCount: number }, rank: number) {
  if (!player.answeredCount) return 0
  return 25 + player.correct * 25 + player.fastestWins * 10 + ([100, 60, 30][rank] || 0)
}
